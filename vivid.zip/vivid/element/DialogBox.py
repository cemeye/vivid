import time
from tools import *

pygame.init()
image_dict = load_imgs('../material/system/')
screen = pygame.display.set_mode((500, 500))
print(image_dict)


# 普通对话框
class DialogBox:
    def __init__(self, text, screen):
        self.text = text
        self.flag = True
        self.screen = screen
        self.flag_text = ''
        self.flag_index = 0
        self.index = 0

    def dialog_run(self):
        while self.flag:
            self.screen.blit(image_dict['DialogBox'], (5, 375))
            draw_text(self.flag_text, (110, 400), self.screen)
            self.one_by_one_word()
            draw_name_and_head(self.text[self.index][0], image_dict[self.text[self.index][0]], self.screen)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_n:
                        self.next()
            pygame.display.update()

    def next(self):
        if self.index + 1 < len(self.text):
            self.index += 1
            self.flag_text = ''
            self.flag_index = 0
        else:
            self.flag = False

    def one_by_one_word(self):
        words = self.text[self.index][1]
        if self.flag_index < len(words):
            self.flag_text += words[self.flag_index]
            self.flag_index += 1
        time.sleep(0.05)

    def reset_dialog(self):
        self.flag = True
        self.flag_text = ''
        self.flag_index = 0
        self.index = 0


# 旁白对话框
class PangBaiDialogBox:
    def __init__(self, text, screen):
        self.text = text
        self.flag = True
        self.screen = screen
        self.flag_index = 0
        self.flag_text = ''
        self.index = 0

    def dialog_run(self):
        while self.flag:
            self.screen.blit(image_dict['PangBaiDialogBox'], (5, 375))
            draw_text('*' + self.flag_text, (60, 410), self.screen)
            self.one_by_one_word()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_n:
                        self.next()
            pygame.display.update()

    def next(self):
        if self.index + 1 < len(self.text):
            self.index += 1
            self.flag_text = ''
            self.flag_index = 0
        else:
            self.flag = False

    def one_by_one_word(self):
        words = self.text[self.index]
        if self.flag_index < len(words):
            self.flag_text += words[self.flag_index]
            self.flag_index += 1
        time.sleep(0.05)

    def reset_dialog(self):
        self.flag = True
        self.flag_index = 0
        self.flag_text = ''
        self.index = 0


# 选择对话框
class ChooseDialogBox:
    def __init__(self, text, screen, then):
        self.text = text
        self.flag = True
        self.then = then
        self.screen = screen
        self.index = 0
        self.conor_pos = [5, 415]
        self.result = 'a'

    def dialog_run(self):
        while self.flag:
            self.screen.blit(image_dict['ChooseDialogBox'], (5, 375))
            draw_choices(self.text, self.screen)
            self.screen.blit(image_dict['conor'], self.conor_pos)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_n:
                        self.flag = False
                        self.next()
                    elif event.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT]:
                        dict_key = {pygame.K_UP: 'up', pygame.K_DOWN: 'down', pygame.K_LEFT: 'left',
                                    pygame.K_RIGHT: 'right'}
                        self.change_conor(dict_key[event.key])

            pygame.display.update()

    def change_conor(self, position):
        if (self.result == 'a' or self.result == 'c') and position == 'right':
            if self.result == 'a':
                self.result = 'b'
            else:
                self.result = 'd'
            self.conor_pos[0] += 240

        elif (self.result == 'b' or self.result == 'd') and position == 'left':
            if self.result == 'b':
                self.result = 'a'
            else:
                self.result = 'c'
            self.conor_pos[0] -= 240
        elif (self.result == 'c' or self.result == 'd') and position == 'up':
            if self.result == 'c':
                self.result = 'a'
            else:
                self.result = 'b'
            self.conor_pos[1] -= 30
        elif (self.result == 'a' or self.result == 'b') and position == 'down':
            if self.result == 'a':
                self.result = 'c'
            else:
                self.result = 'd'
            self.conor_pos[1] += 30

    def next(self):
        self.flag = False
        result_text = {'a': self.then[0], 'b': self.then[1], 'c': self.then[2], 'd': self.then[3]}
        next_dialog = PangBaiDialogBox(result_text[self.result], self.screen)
        next_dialog.dialog_run()

    def reset_dialog(self):
        self.flag = True
        self.screen = screen
        self.index = 0
        self.conor_pos = [5, 415]
        self.result = 'a'


# 对话框组
class DialogGroup:
    def __init__(self, dialogs):
        self.dialogs = dialogs

    def dialogs_run(self):
        for i in self.dialogs:
            i.dialog_run()

    def reset_dialogs(self):
        for i in self.dialogs:
            i.reset_dialog()
