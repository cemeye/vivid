import os
import copy
import pygame
from PIL import Image
import tools
from scene import Scene
from element import Person_walk
from element import RealObj
from element import biology
from widgets import Work_Persent, inventory


def rotating_images(img_path, angle):
    """逆时针旋转图像,返回surface对象"""
    img = Image.open(img_path)
    img_new = img.rotate(int(angle))
    img_new.save('./rotate_new.png')
    img_new_surface = pygame.image.load('./rotate_new.png')
    os.remove('./rotate_new.png')
    return img_new_surface


def rotating_images_s(img_path, angle):
    """逆时针旋转图像，但只返回旋转后地址"""
    img = Image.open(img_path)
    if angle == 90:
        img_new = img.transpose(Image.ROTATE_90)
    elif angle == 270:
        img_new = img.transpose(Image.ROTATE_270)
    else:
        img_new = img.rotate(int(angle))
    img_new.save('./rotate_new.png')
    return './rotate_new.png'


def check_two_rect_intersect(rect1, rect2, type_=True):
    """
    rect1请尽量传入rect2小的矩形，为了性能考虑
    另；此种方法仅适用于检测运动物体，对于静止的一些个例失效
    Type_:是否开启高精度检测，不开启的话若子弹大于敌人可能检测不准
    """
    points_1 = [[rect1[0], rect1[1]],
                [rect1[2], rect1[1]],
                [rect1[2], rect1[3]],
                [rect1[0], rect1[3]]]
    points_2 = [[rect2[0], rect2[1]],
                [rect2[2], rect2[1]],
                [rect2[2], rect2[3]],
                [rect2[0], rect2[3]]]
    for i in points_1:
        if tools.check_in_rect(i, [rect2[0], rect2[1]], [rect2[2], rect2[3]]):
            return True
    if type_:
        for i in points_2:
            if tools.check_in_rect(i, [rect1[0], rect1[1]], [rect1[2], rect1[3]]):
                return True
    else:
        return False


class Basal_Example:
    """
    为节约CPU资源，防止重复载入图片，定义实例类用于实例化基础子弹类的攻击
    与——Basal_Ammunition——搭配
    """

    def __init__(self, pos, direction, imgs, size):
        self.pos = pos
        self.final_pos = [int(pos[0] + size[2]), int(pos[1] + size[3])]
        self.size = size
        self.direction = direction
        self.img = imgs[direction][0]
        self.flag = True


class Basal_Ammunition:
    """
    最基础的子弹类型，无动画，仅能简单地碰撞并造成伤害
    与——Basal_Example——搭配
    """

    def __init__(self, upper_direction_img_path, speed, damage, size, buff=None):
        self.imgs = {
            'up': [RealObj.resize_img(upper_direction_img_path, size), [1, -1]],
            'down': [RealObj.resize_img(rotating_images_s(upper_direction_img_path, 180), size), [1, 1]],
            'left': [RealObj.resize_img(rotating_images_s(upper_direction_img_path, 90), [0, 0, size[3], size[2]]),
                     [0, -1]],
            'right': [RealObj.resize_img(rotating_images_s(upper_direction_img_path, 270), [0, 0, size[3], size[2]]),
                      [0, 1]]
        }
        self.size = size
        self.speed = speed
        self.damage = damage
        self.example_list = []
        self.buff = buff

    def attack(self, direction, pos):
        """
        单纯添加子弹而已
        |被循环后消失|
        :param direction: 方向
        """
        self.example_list.append(
            Basal_Example(pos, direction, self.imgs, self.size))

    def update_ammunition(self, screen, life_entity_list):
        for i in self.example_list:
            if i.flag:
                if i.pos[0] > 500 or i.pos[0] < 0 or i.pos[1] > 500 or i.pos[1] < 0:  # 检测子弹是否飞出地图边界（仅限于固定式地图）
                    i.flag = False
                else:
                    screen.blit(i.img, i.pos)
                    i.pos[self.imgs[i.direction][1][0]] += self.speed * self.imgs[i.direction][1][1]
                    i.final_pos[self.imgs[i.direction][1][0]] += self.speed * self.imgs[i.direction][1][1]

                if self._check_hit(i, life_entity_list):
                    i.flag = False
            else:
                self.example_list.remove(i)

    def _check_hit(self, example, life_entity_list):
        for i in life_entity_list:
            if check_two_rect_intersect(example.pos + example.final_pos, i.rect):
                i.get_influence(BB=self.damage, Buff=self.buff)
                return True


class CombatAnimation:
    def __init__(self, img_path, size, suspended_frame, time, screen, player_size, corresponding=None):
        """
        用于蓄力攻击的动画对象，具有暂停帧（即蓄力完成后并不攻击，停留在这一帧）
        :param img_path:
        :param size:
        :param suspended_frame:
        :param time:
        :param corresponding:
        """
        self.time = time
        self.show_flag = False
        self.screen = screen
        self.suspended_frame = suspended_frame
        self.direction = 'up'
        self.spirit = biology.split_imgs(img_path, size)
        self.timer = tools.UpgradesTimer(60, time, self._change_index_in_time, len(self.spirit))
        self.timer.flag = [0, False]
        self.player_size = player_size
        if corresponding:
            self.corresponding = corresponding
        else:
            self.corresponding = {'down': 0, 'left': 1, 'right': 2, 'up': 3}
        self.now_img = self.spirit[self.corresponding[self.direction]][0]

    def start_show(self):
        self.show_flag = True

    def stop_show(self, pos):
        self.show_flag = False
        self.reset_all()

    def show_until_suspended(self, pos, direction):
        """
        被循环的展示函数，会在暂停帧处暂停
        :return:None
        """
        self.direction = direction
        if self.show_flag:
            self.timer.update_new(self.timer)
            self.screen.blit(self.now_img, pos)

    def _change_index_in_time(self, obj):
        if obj.flag[0] == self.suspended_frame:
            self.timer.flag[1] = True
            self.timer.times = 0
        self.now_img = self.spirit[self.corresponding[self.direction]][self.timer.flag[0]]
        obj.flag[0] += 1

    def reset_all(self):
        self.timer = tools.UpgradesTimer(60, self.time, self._change_index_in_time, len(self.spirit))
        self.timer.flag = [0, False]
        self.now_img = self.spirit[self.corresponding[self.direction]][0]


class Accumulator:
    """
    任何蓄力型武器所需要实例化的对象，蓄力器
    """

    def __init__(self, time_second_a_accumulator, number_of_accumulators, pos, func, minimum=None):
        self.timer = tools.UpgradesTimer(60, time_second_a_accumulator, self._charge, number_of_accumulators)
        self.timer.flag = 0
        self.number_of_accumulators = number_of_accumulators
        self.time_second_a_accumulator = time_second_a_accumulator
        self.start_flag = False
        self.processing_bar = Work_Persent.Work_Persent((255, 255, 255), number_of_accumulators * 5, pos, 3, 0,
                                                        ("", (255, 255, 255)), tools.FONT)
        self.func = func
        self.spirit = None
        self.pos = [0, 0]
        self.minimum = minimum

    def _charge(self, args):
        args.flag += 1

    def charge_update(self, screen, pos, direction=None):
        self.pos = pos
        if self.timer.flag == self.number_of_accumulators:
            self.processing_bar.set_color((255, 0, 0))  # 设置并画出蓄力条
        else:
            self.processing_bar.set_color((255, 255, 255))
        self.processing_bar.blit_work_persent(screen)
        if self.start_flag:
            self.timer.update_new(self.timer)
            self.processing_bar.set(self.timer.flag * 5)  # 检测是否正在蓄力并更新进度条
            self.processing_bar.set_pos(pos)
        if self.spirit and direction:
            self.spirit.show_until_suspended(pos, direction)

    def start_update(self):
        self.timer = tools.UpgradesTimer(60, self.time_second_a_accumulator, self._charge, self.number_of_accumulators)
        self.timer.flag = 0
        self.start_flag = True
        self.spirit.start_show()

    def stop_charge(self, args):
        self.start_flag = False
        if self.minimum:
            if self.timer.flag > self.minimum:
                self.func(args)
        else:
            self.func(args)
        self.timer.flag = 0
        self.processing_bar.set(0)
        self.spirit.stop_show(args[1])


class ChargeAmmunition(Basal_Ammunition):
    """
    蓄力型弹药，绑定蓄力和攻击动画
    """

    def __init__(self, upper_direction_img_path, speed, damage, size, buff=None):
        super().__init__(upper_direction_img_path, speed, damage, size, buff=buff)
        self.accumulator = None
        self.spirit = None
        self.direction = 'up'

    def update_ammunition(self, screen, life_entity_list):
        for i in self.example_list:
            if i.flag:
                if i.pos[0] > 500 or i.pos[0] < 0 or i.pos[1] > 500 or i.pos[1] < 0:  # 检测子弹是否飞出地图边界（仅限于固定式地图）
                    i.flag = False
                else:
                    screen.blit(i.img, i.pos)
                    i.pos[self.imgs[i.direction][1][0]] += self.speed * self.imgs[i.direction][1][1]
                    i.final_pos[self.imgs[i.direction][1][0]] += self.speed * self.imgs[i.direction][1][1]

                if self._check_hit(i, life_entity_list):
                    i.flag = False
            else:
                self.example_list.remove(i)

    def attack(self, direction, pos):
        """
        单纯添加子弹而已
        |被循环后消失|
        :param direction: 方向
        """
        self.example_list.append(Basal_Example(pos, direction, self.imgs, self.size))

    def bind_animation(self, animation_obj):
        self.accumulator.spirit = animation_obj

    def set_direction(self, direction):
        self.direction = direction

    def bind_accumulator(self, accumulator):
        self.accumulator = accumulator


class LifeEntityBuff:
    """
    此为其他生命实体所受buff的基类，自定义buff时请
    继承此类
    """

    def __init__(self, time_of_duration, execution_interval, FPS=60):
        self.time_of_duration = time_of_duration
        self.timer = tools.UpgradesTimer(FPS, execution_interval, self.effect, time_of_duration)
        self.buff_is_alive = True

    def effect(self, life_entity):
        """
        传入收到此buff的生命对象，进行循环操作
        :param life_entity:
        :return:
        """
        ...

    def possible_recover(self, life_entity):
        """
        可能的恢复，例如：定义buff为在一定不时间内降低移动速度20%，
        在buff效果消失后必须重置此效果，否则某些不可随循环自动改变
        的变量（如：速度，伤害，暴击率等）会一直保留该效果，若buff
        效果仅限于给予伤害，恢复血量等，则不需要此方法
        :param life_entity:
        :return:
        """
        ...

    def append_buff(self, life_entity):
        ...

    def buff_update(self, life_entity):
        if self.buff_is_alive and self.timer.times:
            self.timer.update_new(life_entity)


class PlayerBuff:
    """
    此为玩家所受buff的基类，自定义buff时请
    继承此类
    """

    def __init__(self, time_of_duration, execution_interval, name, buff_img, description, describe_img_path, FPS=60,
                 font_size=20):
        self.time_of_duration = time_of_duration
        self.name = name
        self.buff_img = RealObj.resize_img(buff_img, [0, 0, 40, 40])
        self.timer = tools.UpgradesTimer(FPS, execution_interval, self.effect, time_of_duration)
        self.buff_is_alive = True
        if self.timer.times > 60:
            self.last_time = [int(self.timer.times / 60), self.timer.times // 60]
        else:
            self.last_time = [0, self.timer.times]
        self.font_size = font_size
        self.description = tools.split_str(10, description)

        des = []
        for a in self.description:
            des.append(tools.FONT.render(a, False, (255, 255, 255)))

        self.description.append(
            tools.FONT.render(str(self.last_time[0]) + ':' + str(self.last_time[1]), False, (255, 255, 255)))
        self.description_alive = False
        self.describe_img = RealObj.resize_img(describe_img_path,
                                               [0, 0, 10 * self.font_size, (len(self.description) + 1) * font_size])

    def effect(self, player):
        """
        传入收到此buff的生命对象，进行循环操作
        """
        ...

    def possible_recover(self, player):
        """
        可能的恢复，例如：定义buff为在一定不时间内降低移动速度20%，
        在buff效果消失后必须重置此效果，否则某些不可随循环自动改变
        的变量（如：速度，伤害，暴击率等）会一直保留该效果，若buff
        效果仅限于给予伤害，恢复血量等，则不需要此方法
        """
        ...

    def start_show_description(self, start_pos, final_pos, mouse_pos):
        """
        设置元对象的描述标志位为TRUE
        |单次执行|
        :return: None
        """
        if RealObj.check_point_in_rect(start_pos, final_pos, mouse_pos):
            self.description_alive = True

    def _show_description(self, pos):
        """
        内部私有方法，用于显示描述
        |自循环|
        """
        while self.description_alive:
            screen.blit(self.describe_img, pos)
            for index, b in enumerate(self.description):
                screen.blit(b, (pos[0], pos[1] + index * self.font_size))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.description_alive = False
            pygame.display.update()

    def append_buff(self, player):
        player.item_interface.buff.append(self)

    def buff_update(self, player):
        if self.buff_is_alive and self.timer.times:
            self.timer.update_new(player)
            if self.timer.times > 60:
                self.last_time = [int(self.timer.times / 60), self.timer.times // 60]
            else:
                self.last_time = [0, self.timer.times]
            self.description[-1] = tools.FONT.render(str(self.last_time[0]) + ':' + str(self.last_time[1]), False,
                                                     (255, 255, 255))
        ...

    def buff_click_update(self, pos):
        self._show_description(pos)


class CloseIn_Weapons:
    ...


def kelong(a):
    return copy.deepcopy(a)


def calculation_ammunition_pos(player_pos, player_size, ammunition_size):
    player_center = [player_pos[0] + player_size[0] / 2, player_pos[1] + player_size[1] / 2]
    offset = [ammunition_size[0] / 2, ammunition_size[1] / 2]
    return [player_center[0] - offset[0], player_center[1] - offset[1] + 15]


if __name__ == '__main__':
    path = 'C:\\Users\\Administrator\\Desktop\\type\\'
    screen = pygame.display.set_mode((500, 500))
    scene = Scene.Combat_Immovable_Scene(path + 'bg1.png', [250, 250], path + 'player.png',
                                         [32, 48], 3, screen=screen)
    ba1 = ChargeAmmunition(path + 'jiantou.png', 15, 20, [0, 0, 10, 30])
    walk_trues = {'up': True, 'down': True, 'left': True, 'right': True}
    a1 = inventory.Article(path + 'item.png', [25, 25], '这是一个山的雕塑，你要是坚持认为它是一个中指我也没有办法', path + 'di.png', tools.FONT,
                           '一个雕塑')
    le1 = biology.Neutral_LifeEntity(path + 'animal.png', [48, 64], [250, 250], screen, 0.3)
    le1.bind_attack_obj(biology.AttackObj(0.4, 10,
                                          attack_animation=CombatAnimation(path + 'animal_attack.png', [48, 64], -1,
                                                                           0.1, screen, [32, 48], )))

    le1.bind_drops([biology.Drop(4, 0.5, a1)])
    lel = [le1]


    def accu_func(args):
        ba1.attack(args[0], args[1])


    accu1 = Accumulator(0.2, 5, scene.player.pos, accu_func, minimum=1)
    ca = CombatAnimation(path + 'ca1.png', [50, 50], 2, 0.2, screen, [50, 50])
    ba1.bind_accumulator(accu1)
    ba1.bind_animation(ca)
    scene.player.bind_ammunition(ba1)
    clock = pygame.time.Clock()

    scene.scene_main_loop_new(lel)
