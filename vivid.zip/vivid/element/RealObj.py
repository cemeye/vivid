import pygame
import math
import os
from PIL import Image


def resize_img(img_path, rect):  # x,y,long,width
    try:
        img = Image.open(img_path)
        new_img = img.resize((rect[2], rect[3]))
        new_img.save('./new_img_w.png')
        img = pygame.image.load('./new_img_w.png')
        os.remove('./new_img_w.png')
        return img
    except ValueError:
        return False


def return_S(point1, point2) -> float:
    """
    返回两点间的距离
    :param point1:点1 <- (int,int)
    :param point2: 点2 <- (int,int)
    :return: 距离s -> float
    """
    s = math.sqrt(abs(point1[0] - point2[0]) + abs(point1[1] - point2[1]))
    return s


def check_point_in_rect(start, final, point) -> bool:
    """
    检测点是否在矩形内部
    :param start: 矩形起始点
    :param final:矩形终结点
    :param point:被检测点
    :return:bool
    """
    if start[0] < point[0] < final[0] and start[1] < point[1] < final[1]:
        return True
    else:
        return False


def clac_linear_function(point1, point2):
    """
    此函数用于计算一元一次函数
    :return: (k,b)
    """
    a = (point1[1] * 10 - point2[1] * 10) / 10
    b = (point1[0] * 10 - point2[0] * 10) / 10
    k = abs(a) / abs(b)
    if (a > 0 and b > 0) or (a < 0 and b < 0):
        b = point1[1] - k * point1[0]
        return k, b
    else:
        k *= -1
        b = point1[1] - k * point1[0]
        return k, b


class Real_Obj:
    """
    此类用于实现实体的创建，配合矩形绘制实现
    方法有碰撞检测（需传入角色中心点进行检测）
    """

    def __init__(self, pos, final_pos, player_size, img_path):
        self.player_size = player_size
        self.pos = pos
        self.final_pos = final_pos
        self.long = self.final_pos[0] - self.pos[0]
        self.width = self.final_pos[1] - self.pos[1]

        self.around_rect_pos = [self.pos[0] - player_size[0] / 2, self.pos[1] - player_size[1] / 2]
        self.around_rect_fin = [self.final_pos[0] + player_size[0] / 2, self.final_pos[1] + player_size[1] / 2]
        self.around_rects = []

        self.ks_bs = []  # 左上，右上，右下，左下
        self._init_rects_kb()
        self.dialogs = False
        self.img = resize_img(img_path, [self.pos[0], self.pos[0], self.long, self.width])
        self.duiying = {'up': 'down', 'left': 'right', 'down': 'up', 'right': 'left'}

    def collision_detection(self, player_center_pos, trues):
        """
        此方法用与检测玩家与实体是否碰撞
        :return: bool
        """
        rect_list = []

        if check_point_in_rect(self.around_rect_pos, self.around_rect_fin, player_center_pos):
            self.recalculate()
            for i in self.around_rects:
                if check_point_in_rect(i[0], i[1], player_center_pos):
                    rect_list.append(i)
            if len(rect_list) == 1:
                trues[self.duiying[rect_list[0][2]]] = False

                return trues
            else:
                return {'up': True, 'down': True, 'left': True, 'right': True}

    def recalculate(self):
        self.around_rects = []
        self.around_rect_pos = [self.pos[0] - self.player_size[0] / 2, self.pos[1] - self.player_size[1] / 2]
        self.around_rect_fin = [self.final_pos[0] + self.player_size[0] / 2,
                                self.final_pos[1] + self.player_size[1] / 2]
        self.around_rects.append([self.around_rect_pos, (self.around_rect_fin[0], self.pos[1]), 'up'])
        self.around_rects.append([(self.around_rect_pos[0], self.final_pos[1]), self.around_rect_fin, 'down'])
        self.around_rects.append([self.around_rect_pos, (self.pos[0], self.around_rect_fin[1]), 'left'])
        self.around_rects.append([(self.final_pos[0], self.around_rect_pos[1]), self.around_rect_fin, 'right'])
        # self.ks_bs = []  # 左上，右上，右下，左下
        # self._init_rects_kb()

    def draw_self(self, screen):
        screen.blit(self.img, self.pos)

    def _init_rects_kb(self):
        """
        用于初始化周边矩形（内部私有方法）
        :return: None
        """
        self.around_rects.append([self.around_rect_pos, (self.around_rect_fin[0], self.pos[1]), 'up'])
        self.around_rects.append([(self.around_rect_pos[0], self.final_pos[1]), self.around_rect_fin, 'down'])
        self.around_rects.append([self.around_rect_pos, (self.pos[0], self.around_rect_fin[1]), 'left'])
        self.around_rects.append([(self.final_pos[0], self.around_rect_pos[1]), self.around_rect_fin, 'right'])

        self.ks_bs.append(clac_linear_function(self.around_rect_pos, self.pos))
        self.ks_bs.append(
            clac_linear_function((self.around_rect_fin[0], self.around_rect_pos[1]), (self.final_pos[0], self.pos[1])))
        self.ks_bs.append(clac_linear_function(self.final_pos, self.around_rect_fin))
        self.ks_bs.append(
            clac_linear_function((self.pos[0], self.final_pos[1]), (self.around_rect_pos[0], self.around_rect_fin[1])))


class Real_Obj_With_Dialog(Real_Obj):
    def __init__(self, pos, final_pos, player_size, img_path, dialog_group):
        super().__init__(pos, final_pos, player_size, img_path)
        self.dialogs = dialog_group

    def show_dialog(self):
        self.dialogs.dialogs_run()


class SceneChange_Obj:
    def __init__(self, screen, pos, final_pos, ID, animation=None):
        self.pos = pos
        self.final_pos = final_pos
        self.ID = ID
        self.screen = screen
        self.animation = animation

    def change_scene(self, CCU, scene_adapter, player, ID, life_entity=None, enemy=None):
        if not self.animation:
            self.animation.animation_show(self.screen)
        scene_adapter.reset_scene(CCU, player, ID, life_entity, enemy)
