import pygame
import sys
import tools
import time


# screen = pygame.display.set_mode((500, 500))
# pygame.display.init()
# pygame.font.init()
# font = pygame.font.Font('./system/system material/pix.ttf', 20)


class TUD:
    def __init__(self, texts, speed, font):
        self.texts = texts
        self.font = font
        self.text_render = []
        self.speed = speed
        self._render_text()
        self.flag = True

    def _render_text(self):
        for i in self.texts:
            text_r = self.font.render(i[0], False, i[1])
            self.text_render.append(text_r)

    def run(self, screen):
        text_poses = []
        for i in range(0, len(self.text_render)):
            text_poses.append([60, 515 + i * 25])
        while self.flag:
            screen.fill((0, 0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

            for i, ii in zip(self.text_render, text_poses):
                screen.blit(i, ii)
            for i in text_poses:
                i[1] -= self.speed
                time.sleep(0.01)
            if text_poses[-1][1] < -30:
                self.flag = False
            pygame.display.update()


class HTUD:
    def __init__(self, size, text, speed, font):
        self.font = font
        self.text_render = []
        self.speed = speed
        self._render_text(size, text)

    def _render_text(self, size, text):
        texts = tools.split_str(size, text)
        for i in texts:
            text_r = self.font.render(i[0], False, i[1])
            self.text_render.append(text_r)

    def run(self, screen):
        text_poses = []
        for i in range(0, len(self.text_render)):
            text_poses.append([60, 515 + i * 25])
        while self.flag:
            screen.fill((0, 0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

            for i, ii in zip(self.text_render, text_poses):
                screen.blit(i, ii)
            for i in text_poses:
                i[1] -= self.speed
                time.sleep(0.01)
            if text_poses[-1][1] < -30:
                self.flag = False
            pygame.display.update()

# if __name__ == '__main__':
#     tud1 = TUD([('大家好,我是一个很牛逼的程序员', (255, 0, 0)),
#                 ('今天做这个字幕不为别的，就为了装逼', (255, 255, 255))
#                 ]
#                , 5, font)
#     tud1.run(screen)
