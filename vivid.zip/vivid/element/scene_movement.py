import pygame.display
import tools
import time


class GSPB:
    """
    Gradual Scenario Prompt Box(渐变式场景提示框)
    """

    def __init__(self, img_path, text, speed, pos, font, color=(255, 255, 255), interval=2):
        self.img = tools.resize_img(img_path, [600, 150])
        self.text = font.render(text, False, color)

        self.interval = interval

        self.img.set_alpha(0)
        self.text.set_alpha(0)

        self.pos = pos
        self.speed = speed

        self.alpha_value = 0
        self.first = True
        self.top = False
        self.flag = True

    def _sleep(self):
        if self.first:
            time.sleep(self.interval)

    def _change_alpha(self):
        if self.alpha_value < 255 and not self.top:
            self.img.set_alpha(self.alpha_value)
            self.text.set_alpha(self.alpha_value)
            time.sleep(0.05)
            self.alpha_value += self.speed
            print(self.alpha_value)
        elif self.alpha_value > 0:
            self._sleep()
            self.top = True
            self.img.set_alpha(self.alpha_value)
            self.text.set_alpha(self.alpha_value)
            time.sleep(0.05)
            self.alpha_value -= self.speed
            print(self.alpha_value)
            self.first = False
        else:
            self.flag = False

    def GSPB_run(self, screen):
        while self.flag:
            screen.fill((255, 255, 255))
            screen.blit(self.img, [-50, 180])
            screen.blit(self.text, self.pos)
            self._change_alpha()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
            pygame.display.update()


if __name__ == '__main__':
    screen = pygame.display.set_mode((500, 500))
    a1 = GSPB('C:\\Users\\Administrator\\Desktop\\type\\scene_curtain.png', '测试场景', 10, [50, 250], tools.FONT)

    while True:
        screen.fill((255, 0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
        a1.GSPB_run(screen)
