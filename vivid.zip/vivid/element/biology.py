from PIL import Image
import pygame
import tools
from initiator import errors
import os
import random


def split_imgs(img_path, size):
    """
    此函数用于划分对象图片
    :return: None
    """
    img = Image.open(img_path)
    spirit = []
    for i in range(0, 4):
        img_list = []
        for ii in range(0, 4):
            new_img = img.crop((size[0] * ii, size[1] * i, size[0] * ii + size[0], size[1] * i + size[1]))
            img_list.append(new_img)
        surface_img = []
        for a in img_list:
            a.save('./1.png')
            surface_img.append(pygame.image.load('./1.png'))
        spirit.append(surface_img)
    os.remove('./1.png')
    return spirit


def shallow_copy(a):
    """
    克隆函数，在不损伤原对象的情况下返回一个全新的对象
    无需担心原对象被更改造成的错误，且克隆的新对象会被
    Python垃圾回收机制处理，创建的新对象会在用完后被
    销毁
    :param a: 原对象
    :return: 克隆后的新对象
    """
    n_a = a
    return n_a


def _random_create_drop_pos(pos):
    new_rect = [round(pos[0] - 50), round(pos[1] - 50), round(pos[0] + 50), round(pos[1] + 50)]
    new_pos = [random.randint(new_rect[0], new_rect[2]), random.randint(new_rect[1], new_rect[3])]
    return new_pos


class Drop:
    def __init__(self, times, probability, article, must_fall=None):
        """
        掉落物
        :param times: 掉落次数（也可以认为是最大掉落数）
        :param probability: 概率字符串，范围：0.000001 ~ 1，最好不要低于一百万分之一
        :param article: 掉落的物品对象
        :param must_fall: 若需必须掉落，则为必须掉落的个数（可选参数）
        """
        self.times = times
        self.probability = probability
        self.article = article
        self.must_fall = must_fall

        self.final_drop = []

    def _change_probability(self):
        if float(self.probability) > 1:
            raise errors.VividError(code=10009, status='概率错误！')
        elif float(self.probability) < 0.000001:
            raise errors.VividError(code=10010, status='概率错误！')
        else:
            cardinal_number = pow(10, len(str(self.probability).split('.')[1]))
            probability = float(self.probability) * cardinal_number
            if 0 <= random.randint(0, cardinal_number) <= probability:
                return True
            else:
                return False

    def drop(self, pos):
        if self.must_fall:
            for i in range(self.must_fall):
                self.final_drop.append(shallow_copy(self.article))
        for i in range(self.times):
            if self._change_probability():
                self.final_drop.append([self.article, _random_create_drop_pos(pos)])
        return self.final_drop


class LifeEntity:
    """
    及其低能的AI，是其他生物的基类，但是当个普通的，具有掉落物，可自由
    在范围内行走的简单又好生物还是可以的。只能被动挨打，不会对打击做出
    任何反应
    [！]不推荐进行实例化
    """

    def __init__(self, img_path, size, pos, screen, speed, die_animation=None, corresponding=None, change_speed=0.3,
                 frame_num=4, patrol_size=100, HP=100):
        self.HP = HP  # 生命值
        self.pos = pos
        self.speed = speed
        self.is_alive = True
        self.birthplace = pos
        self.rect = [self.pos[0], self.pos[1], self.pos[0] + size[0], self.pos[1] + size[1]]
        self.drop = []
        self.img_path = img_path
        self.size = size
        self.spirit = []
        self._split_imgs()
        self.screen = screen

        self.timer = tools.UpgradesTimer(60, change_speed, self._change_img_index, 'infinity')
        self.timer.flag = 0
        self.walk_info = [0, 'down']
        self.frame_num = frame_num

        if corresponding:
            self.corresponding = corresponding
        else:
            self.corresponding = {'down': [0, [1, 1]], 'left': [1, [0, -1]], 'right': [2, [0, 1]], 'up': [3, [1, -1]]}

        self.now_img = self.spirit[self.corresponding['down'][0]][0]
        self.direction = 'down'
        self.die_animation = die_animation  # 可能有的死亡动画
        self.final_drop = []

        self.buff = []

        self.patrol_timer = tools.UpgradesTimer(60, 1, self._random_walk, 'infinity')
        self.patrol_rect = [pos[0] - patrol_size, pos[1] - patrol_size, pos[0] + patrol_size, pos[1] + patrol_size]

    def start_walk(self, position, distance):
        self.walk_info = [distance, position]

    def _change_img_index(self, position):
        self.direction = position
        self.now_img = self.spirit[self.corresponding[position][0]][self.timer.flag]
        if self.timer.flag + 1 < self.frame_num:
            self.timer.flag += 1
        else:
            self.timer.flag = 0

    def _split_imgs(self):
        """
        此函数用于划分对象图片
        :return: None
        """
        img = Image.open(self.img_path)
        for i in range(0, 4):
            img_list = []
            for ii in range(0, 4):
                new_img = img.crop((self.size[0] * ii, self.size[1] * i, self.size[0] * ii + self.size[0],
                                    self.size[1] * i + self.size[1]))
                img_list.append(new_img)
            surface_img = []
            for a in img_list:
                a.save('./1.png')
                surface_img.append(pygame.image.load('./1.png'))
            self.spirit.append(surface_img)
        os.remove('./1.png')

    def get_HP(self):
        return self.HP

    def die(self, scene):
        if self.die_animation:
            self.die_animation.animation_show(self.screen)
        if self.drop:
            for i in self.drop:
                self.final_drop.append(i.drop(self.pos))
            for i in self.final_drop:
                scene.drop.append(i)
        self.is_alive = False

    def bind_drops(self, drop_list):
        self.drop = drop_list

    def _check_vector(self, position, s) -> bool:
        center = [self.pos[0] + self.size[0] / 2, self.pos[1] + self.size[1] / 2]
        center[self.corresponding[position][1][0]] += s * self.corresponding[position][1][1]
        if tools.check_point_in_rect(self.patrol_rect[0:2], self.patrol_rect[2:4], center):
            print('进行行走')
            return True
        else:
            print('不可行走')
            return False

    def _random_walk(self, possibility_of_action):
        """
        根据规则随机行走，以生成地为原中心点，以传入参数为正方形半长内进行“巡视”
        :return: None
        """
        walk_list = ['up', 'down', 'left', 'right']
        position = walk_list[random.randint(0, 3)]
        s = random.randint(20, 50)
        if tools.create_result_for_probability(possibility_of_action):
            print(self.patrol_rect[self.corresponding[position][1][0]],
                  self.pos[self.corresponding[position][1][0]],
                  s)
            if self._check_vector(position, s):
                self.start_walk(position, s)

    def get_influence(self, BB=0, RB=0, Buff=None):
        """
        此方法用于影响实体状态，包括加血，减血，增加BUFF等等
        :param BB: 减血
        :param RB: 加血
        :param Buff: 增加状态对象
        :return: None
        """
        if BB:
            self.HP -= BB
        if RB:
            self.HP += RB
        if Buff:
            self.buff.append(Buff)

    def life_entity_update(self, scene, possibility_of_action):
        self.rect = [self.pos[0], self.pos[1], self.pos[0] + self.size[0], self.pos[1] + self.size[1]]  # 刷新矩形
        self.screen.blit(self.now_img, self.pos)
        self.patrol_timer.update_new(possibility_of_action)
        if self.buff:
            for i in self.buff:
                i.buff_update(self)

        if self.HP <= 0:
            self.die(scene)

        if self.walk_info[0] > 0:
            self.pos[self.corresponding[self.walk_info[1]][1][0]] += self.speed * \
                                                                     self.corresponding[self.walk_info[1]][1][1]
            self.timer.update_new(self.walk_info[1])
            self.walk_info[0] = self.walk_info[0]-self.speed
        elif self.walk_info[0] <= 0:
            self.walk_info[0] = 0
            self.now_img = self.spirit[self.corresponding[self.walk_info[1]][0]][0]


class CombatAnimation:
    def __init__(self, img_path, size, time, screen, corresponding=None):
        """
        用于蓄力攻击的动画对象
        """
        self.time = time
        self.show_flag = False
        self.screen = screen
        self.direction = 'up'
        self.spirit = split_imgs(img_path, size)
        self.timer = tools.UpgradesTimer(60, time, self._change_index_in_time, len(self.spirit))
        self.timer.flag = [0, False]
        if corresponding:
            self.corresponding = corresponding
        else:
            self.corresponding = {'down': 0, 'left': 1, 'right': 2, 'up': 3}
        self.now_img = self.spirit[self.corresponding[self.direction]][0]

    def start_show(self):
        self.show_flag = True

    def stop_show(self):
        self.show_flag = False
        self.reset_all()

    def _change_index_in_time(self, obj):
        self.now_img = self.spirit[self.corresponding[self.direction]][self.timer.flag[0]]
        obj.flag[0] += 1

    def reset_all(self):
        self.timer = tools.UpgradesTimer(60, self.time, self._change_index_in_time, len(self.spirit))
        self.timer.flag = [0, False]
        self.now_img = self.spirit[self.corresponding[self.direction]][0]

    def show(self, pos, direction):
        """
        被循环的展示函数，会在暂停帧处暂停
        :return:None
        """
        self.direction = direction
        if self.show_flag:
            self.timer.update_new(self.timer)
            self.screen.blit(self.now_img, pos)


class AttackObj:
    def __init__(self, interval, damage, buff=None, attack_animation=None):
        self.buff = buff
        self.damage = damage
        self.interval = interval
        self.attack_animation = attack_animation
        self.attack_timer = tools.UpgradesTimer(60, interval, self._attack_function, 'infinity')

    def _attack_function(self, arg_list):
        arg_list[0].HP -= self.damage  # 扣除伤害
        print('当前生物剩余血量：', arg_list[0].HP)
        if self.buff:
            for i in self.buff:  # 添加BUFF
                arg_list[0].buff.append(i)
        # arg_list[1].attack_flag = False
        self.attack_animation.reset_all()
        self.attack_timer.reset()
        self.reset_all()

    def reset_all(self):
        self.attack_animation.reset_all()
        self.attack_timer.reset()

    def attack(self, life_entity, pos, direction, attacker):
        self.attack_timer.update_new([life_entity, attacker])
        if self.attack_animation:
            self.attack_animation.start_show()
            self.attack_animation.show_until_suspended(pos, direction)


class Immovable_LifeEntity(LifeEntity):
    def __init__(self, img_path, size, pos, screen, speed, die_animation=None, corresponding=None, change_speed=0.3,
                 frame_num=4, patrol_size=100):
        super().__init__(img_path, size, pos, screen, speed, die_animation=die_animation, corresponding=corresponding,
                         change_speed=change_speed,
                         frame_num=frame_num, patrol_size=patrol_size)
        self.immovable = True
        self.position = 'down'

    def start_walk(self, position, distance):
        ...

    def _random_walk(self, possibility_of_action):
        ...

    def change_position(self, position):
        self.position = position

    def life_entity_update_new(self, scene):
        self.rect = [self.pos[0], self.pos[1], self.pos[0] + self.size[0], self.pos[1] + self.size[1]]  # 刷新矩形
        self.screen.blit(self.now_img, self.pos)
        self.timer.update_new(self.position)
        if self.HP <= 0:
            self.die(scene)


class Neutral_LifeEntity(LifeEntity):
    def __init__(self, img_path, size, pos, screen, speed, die_animation=None, corresponding=None, change_speed=0.3,
                 frame_num=4, patrol_size=100):
        super().__init__(img_path, size, pos, screen, speed, die_animation=die_animation, corresponding=corresponding,
                         change_speed=change_speed,
                         frame_num=frame_num, patrol_size=patrol_size)
        self.state_anger = False
        self.attack_obj = None
        self.attack_flag = False

    def get_influence(self, BB=0, RB=0, Buff=None):
        if BB:
            self.HP -= BB
            self.state_anger = True
            print('成功惹怒此生物,当前血量:', self.HP)
        if RB:
            self.HP += RB
        if Buff:
            self.buff.append(Buff)

    def bind_attack_obj(self, attack_obj):
        self.attack_obj = attack_obj

    def automatic_pathfinding(self, player_rect):
        x_dv = abs(player_rect[0] - self.pos[0])
        y_dv = abs(player_rect[1] - self.pos[1])
        x_flag = 'left'
        y_flag = 'up'

        if player_rect[0] > self.pos[0]:
            self.pos[0] += self.speed
            x_flag = 'right'
        else:
            self.pos[0] -= self.speed
        if player_rect[1] > self.pos[1]:
            self.pos[1] += self.speed
            y_flag = 'down'
        else:
            self.pos[1] -= self.speed

        if x_dv > y_dv:
            self.start_walk(x_flag, self.speed)
        else:
            self.start_walk(y_flag, self.speed)

    def check_overlap(self, player_rect):
        if tools.check_two_rect_intersect(rect1=player_rect, rect2=self.rect):
            return True
        else:
            return False

    def life_entity_update_new(self, scene, possibility_of_action, player):
        self.rect = [self.pos[0], self.pos[1], self.pos[0] + self.size[0], self.pos[1] + self.size[1]]  # 刷新矩形
        if not self.attack_flag:
            self.screen.blit(self.now_img, self.pos)
            self.attack_obj.reset_all()

        self.patrol_timer.update_new(possibility_of_action)

        if self.buff:
            for i in self.buff:
                i.buff_update(self)

        if self.HP <= 0:
            self.die(scene)

        if self.walk_info[0] > 0:
            self.pos[self.corresponding[self.walk_info[1]][1][0]] += self.speed * \
                                                                     self.corresponding[self.walk_info[1]][1][1]
            self.timer.update_new(self.walk_info[1])
            self.walk_info[0] -= self.speed
        elif self.walk_info[0] <= 0:
            self.walk_info[0] = 0
            self.now_img = self.spirit[self.corresponding[self.walk_info[1]][0]][0]

        if self.state_anger:
            if not self.attack_flag:
                self.automatic_pathfinding(player.rect)
            if self.check_overlap(player.rect):
                print('寻路中......')
                self.attack_flag = True
                try:
                    self.attack_obj.attack(player, self.pos, self.direction, self)
                except AttributeError:
                    raise errors.VividError(code=10012, status='未绑定攻击实体')
            else:
                self.attack_flag = False
                self.attack_obj.reset_all()


if __name__ == '__main__':
    path = 'C:\\Users\\Administrator\\Desktop\\type\\'
    screen = pygame.display.set_mode((500, 500))
    clock = pygame.time.Clock()
    a1 = Neutral_LifeEntity(path + 'animal.png', [48, 64], [250, 250], screen, 1)

    while True:
        screen.fill((0, 0, 0))
        clock.tick(60)
        a1.life_entity_update(None, 0.5)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    a1.start_walk('left', 20)
                elif event.key == pygame.K_d:
                    a1.start_walk('right', 20)
                elif event.key == pygame.K_w:
                    a1.start_walk('up', 20)
                elif event.key == pygame.K_s:
                    a1.start_walk('down', 20)
        pygame.display.update()
