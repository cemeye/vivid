import pygame
import os
import tools

screen = pygame.display.set_mode((500, 500))

def load_animation_img(imgs_path):
    file_list = os.listdir(imgs_path)
    surface_list = []
    for i in range(1, len(file_list)+1):
        surface_list.append(pygame.image.load(imgs_path+'/'+str(i)+'.png'))
    return surface_list


class Animation:
    def __init__(self, imgs, speed, pos):
        self.flag = True
        self.pos = pos
        self.imgs = imgs
        self.img_index = 0
        self.now_img = self.imgs[self.img_index]
        self.timer = tools.Timer(60, speed, lambda: self._change_img_index(), len(imgs))

    def _change_img_index(self):
        if self.img_index < len(self.imgs) - 1:
            self.img_index += 1
            self.now_img = self.imgs[self.img_index]
        else:
            self.flag = False

    def animation_show(self, screen):
        while self.flag:
            screen.blit(self.now_img, self.pos)
            self.timer.update()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
            pygame.display.update()

    def change_pos(self, new_pos):
        self.pos = new_pos


class Fixed_Animation(Animation):
    def animation_show(self, screen, ):
        while self.flag:
            screen.blit(self.now_img, self.pos)
            self.timer.update()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
            pygame.display.update()



