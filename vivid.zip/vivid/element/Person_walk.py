import os
import pygame
from PIL import Image
from initiator import errors
import tools
from element import combat_system


class Person:
    def __init__(self, img_path, init_pos, speed, size, HP=1000):
        """
        此对象定义了可移动或由玩家操作的角色
        :param img_path: 角色图片路径
        :param init_pos: 在屏幕上的初始的位置
        :param speed: 角色移动的速度
        """
        self.img_path = img_path
        self.size = size
        self.spirit = []
        self._split_imgs()
        self.pos = init_pos
        self.rect = [self.pos[0], self.pos[1], self.pos[0] + self.size[0], self.pos[1] + self.size[1]]
        self.walk_list = {'down': (1, 1), 'left': (0, -1), 'right': (0, 1), 'up': (1, -1)}
        self.speed = speed
        self.img = self.spirit[0][0]
        self.walk = False
        self.position = {'down': self.spirit[0], 'left': self.spirit[1], 'right': self.spirit[2], 'up': self.spirit[3]}
        self.now_position = self.position['down']
        self.timer = tools.Timer(60, 0.1, lambda: self.change_index(), 'infinity')
        self.img_index = 0
        self.flag_forward = 0
        self.center = [int(init_pos[0] / 2), int(init_pos[1] / 2)]

        self.trues = {'up': True, 'down': True, 'left': True, 'right': True}
        self.HP = HP

    def _split_imgs(self):
        """
        此函数用于划分对象图片
        :return: None
        """
        img = Image.open(self.img_path)
        for i in range(0, 4):
            img_list = []
            for ii in range(0, 4):
                new_img = img.crop((self.size[0] * ii, self.size[1] * i, self.size[0] * ii + self.size[0],
                                    self.size[1] * i + self.size[1]))
                img_list.append(new_img)
            surface_img = []
            for a in img_list:
                a.save('./1.png')
                surface_img.append(pygame.image.load('./1.png'))
            self.spirit.append(surface_img)
        os.remove('./1.png')

    def change_index(self):
        """
        此函数用于检测精灵下标，并改变精灵下标
        :return: None
        """
        if self.img_index + 1 <= 3:
            self.img_index += 1

        else:
            self.img_index = 0
        self.img = self.now_position[self.img_index]

    def stop_walk(self):
        """
        停止行走，将self。walk设置为False
        :return: None
        """
        self.walk = False

    def start_walk(self, position):
        """
        设定朝某个方向行走（并不是行走调用函数）
        :param trues: 是否可以行走
        :param position:方向字符串包含（up,down,left,right）
        :return: None
        """
        if self.trues[position]:
            self.walk = position
            self.now_position = self.position[position]
        else:
            self.stop_walk()

    def check(self, walk_trues):
        """
        检测按键，并对按键做出行走相应
        :return: None
        """
        self.center = [int(self.pos[0] + (self.size[0] / 2)), int(self.pos[1] + (self.size[1] / 2))]
        self.trues = walk_trues
        self.rect = [self.pos[0], self.pos[1], self.pos[0] + self.size[0], self.pos[2] + self.size[1]]
        if self.walk and self.trues[self.walk]:
            self.timer.update()
            type_ = self.walk_list[self.walk]
            self.pos[type_[0]] += type_[1] * self.speed
        else:
            self.img = self.now_position[0]

    def draw_person(self, screen):
        screen.blit(self.img, self.pos)

    def check_in_movable_scene(self, walk_trues):
        self.center = [int(self.pos[0] + (self.size[0] / 2)), int(self.pos[1] + (self.size[1] / 2))]
        self.trues = walk_trues
        if self.walk and self.trues[self.walk]:
            self.timer.update()
        else:
            self.img = self.now_position[0]

    def just_show_walk(self, position):
        self.walk = position
        self.now_position = self.position[position]

    def just_stop_walk(self):
        self.walk = False
        self.img = self.now_position[0]


class AssaultPlayer(Person):
    def __init__(self, img_path, init_pos, speed, size):
        super().__init__(img_path, init_pos, speed, size)
        self.ammunition = None
        self.danyao_pos = combat_system.calculation_ammunition_pos(self.pos, [50, 50], [10, 30])
        self.item_interface = None
        self.buff = []

    def start_walk(self, position):
        """
        设定朝某个方向行走（并不是行走调用函数）
        :param trues: 是否可以行走
        :param position:方向字符串包含（up,down,left,right）
        :return: None
        """
        self.ammunition.set_direction(position)
        if not self.ammunition.accumulator.start_flag:
            if self.trues[position]:
                self.walk = position
                self.now_position = self.position[position]
            else:
                self.stop_walk()

    def check_new(self, walk_trues, lel, screen):
        """
        检测按键，并对按键做出行走相应
        :param lel:
        :return: None
        """
        self.rect = [self.pos[0], self.pos[1], self.pos[0] + self.size[0], self.pos[1] + self.size[1]]
        self.center = [int(self.pos[0] + (self.size[0] / 2)), int(self.pos[1] + (self.size[1] / 2))]
        self.danyao_pos = combat_system.calculation_ammunition_pos(self.pos, [50, 50], [10, 30])
        self.trues = walk_trues
        if self.walk and self.trues[self.walk]:
            if not self.ammunition.accumulator.start_flag:
                self.timer.update()
                type_ = self.walk_list[self.walk]
                self.pos[type_[0]] += type_[1] * self.speed
        else:
            self.img = self.now_position[0]
        self.ammunition.update_ammunition(screen, lel)
        self.ammunition.accumulator.charge_update(screen, self.pos, self.ammunition.direction)
        if self.item_interface:
            for i in self.item_interface.buff:
                if i.buff_is_alive:
                    i.effect(self)
                else:
                    i.possible_recover(self)
                    try:
                        self.item_interface.buff.remove(i)
                    except ValueError:
                        raise errors.VividError(code=10011, status='属性不存在！')

    def draw_person(self, screen):
        if not self.ammunition.accumulator.start_flag:
            screen.blit(self.img, self.pos)

    def check_in_movable_scene_new(self, walk_trues, lel, screen):
        if not self.ammunition.accumulator.start_flag:
            self.center = [int(self.pos[0] + (self.size[0] / 2)), int(self.pos[1] + (self.size[1] / 2))]
            self.trues = walk_trues
            if self.walk and self.trues[self.walk]:
                self.timer.update()
            else:
                self.img = self.now_position[0]
        self.ammunition.update_ammunition(screen, lel)
        self.ammunition.accumulator.charge_update(screen, self.pos, self.ammunition.direction)
        if self.item_interface:
            for i in self.item_interface.buff:
                if i.buff_is_alive:
                    i.effect(self)
                else:
                    i.possible_recover(self)
                    try:
                        self.item_interface.buff.remove(i)
                    except ValueError:
                        raise errors.VividError(code=10011, status='属性不存在！')

    def just_show_walk(self, position):
        if not self.ammunition.accumulator.start_flag:
            self.walk = position
            self.now_position = self.position[position]

    def just_stop_walk(self):
        if not self.ammunition.accumulator.start_flag:
            self.walk = False
            self.img = self.now_position[0]

    def bind_ammunition(self, ammunition_obj):
        self.ammunition = ammunition_obj

    def bind_item_interface(self, item_interface):
        self.item_interface = item_interface


    def get_influence(self, BB=0, RB=0, Buff=None):
        """
        此方法用于影响实体状态，包括加血，减血，增加BUFF等等
        :param BB: 减血
        :param RB: 加血
        :param Buff: 增加状态对象
        :return: None
        """
        if BB:
            self.HP -= BB
        if RB:
            self.HP += RB
        if Buff:
            for i in Buff:
                self.buff.append(i)
                if self.item_interface:
                    i.append_buff(self)
