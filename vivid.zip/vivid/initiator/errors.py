import pygame.display
import colorama
import tools

error_code = {
    '1000': 'vivid实体错误',
    '10001': 'vivid对话文件与实体文件混合错误',
    '10002': 'vivid按钮函数绑定错误！数量不匹配',
    '10003': 'vivid背包引发错误！数量超出最大上限',
    '10004': 'vivid背包引发错误！找不到对应物体',
    '10005': 'vivid背包引发错误！无法增加唯一性物体数量！',
    '10006': 'vivid背包引发错误！无法绑定带有错误权限标识的物体！',
    '10007': 'vivid背包引发错误！无法为唯一性物品格绑定非唯一性物体！',
    '10008': 'vivid背包引发错误！权限个数与装备格数不匹配！',
    '10009': 'vivid掉落物引发错误！概率无法大于1！',
    '10010': 'vivid掉落物引发错误！概率最好不要小于0.000001（百万分之一）！',
    '10011': 'vivid buff引发错误！buff在移除过程中不存在！',
    '10012': 'vivid 实体攻击引发错误！实体未绑定攻击对象！无法发动攻击！',

}
colorama.init(autoreset=True)


class VividError(Exception):
    def __init__(self, code, status):
        self.message = error_code[str(code)]
        self.code = str(code)
        self.status = status
        print(colorama.Back.RED + 'Traceback (most recent call last):')
        print(colorama.Fore.RED + '错误码:' + self.code)
        print(colorama.Fore.RED + self.status)
        print(colorama.Fore.RED + '在文件' + __file__ + '中,')
        print(colorama.Fore.RED + self.message)
        print(colorama.Back.RED + '===========================')

    def show_vivid_error(self, screen):
        tools.show_error(screen, self.message, str(__file__), tools.FONT, (0, 170))

    def get_message(self):
        print(self.status)
        print('在文件' + __file__ + '中,')
        print(self.message)


if __name__ == '__main__':
    screen = pygame.display.set_mode((500, 500))
    try:
        raise VividError(1000, 'VividError')
    except VividError as v:
        ...
