import json
from element import RealObj, DialogBox


class DialogSceneMixer:
    """
    对话文件场景文件混合器
    """

    def __init__(self, real_obj_path, dialog_path=None):
        self.real_obj_list = json.loads(open(real_obj_path, 'r', encoding='utf-8').read())
        self.index = 0
        self.objs = []
        if dialog_path:
            self.dialog_list = json.loads(open(dialog_path, 'r', encoding='utf-8').read())

    def _check_dialog_type(self, type, screen):
        """
        根据类型计算并生成对话框对象，并返回DialogGroup
        :param type: 类型str
        :param screen: screen
        :return: DialogGroup
        """
        if type != 'DialogGroup':
            if type == 'DialogBox':
                dialog_group = DialogBox.DialogGroup(
                    [DialogBox.DialogBox(self.dialog_list[self.index]['text'], screen)])
            elif type == 'PangBaiDialogBox':
                dialog_group = DialogBox.DialogGroup(
                    [DialogBox.PangBaiDialogBox(self.dialog_list[self.index]['text'], screen)])
            else:
                dialog_group = DialogBox.DialogGroup([DialogBox.ChooseDialogBox(
                    self.dialog_list[self.index]['text'], screen, self.dialog_list[self.index]['result'])])
            return dialog_group
        else:
            dialogs = []
            for i in self.dialog_list[self.index]['dialogs']:
                if i['type'] != 'ChooseDialogBox':
                    if i['type'] == 'DialogBox':
                        dialogs.append(DialogBox.DialogBox(text=i['text'], screen=screen))
                    else:
                        dialogs.append(DialogBox.PangBaiDialogBox(text=i['text'], screen=screen))
                else:
                    dialogs.append(DialogBox.ChooseDialogBox(text=i['text'], screen=screen, then=i['result']))
            return DialogBox.DialogGroup(dialogs=dialogs)

    def mix(self, screen, animation=None):
        """
        混合函数，将对话框与实体合并致一起
        :param screen: screen
        :param animation: 可选参数，动画效果对象
        :return: 返回实体列表
        """
        for i in self.real_obj_list:
            if i['type'] == 'Real_Obj_With_Dialog':
                # pos, final_pos, player_size, img_path, dialog_group
                dialog_group = self._check_dialog_type(self.dialog_list[self.index]['type'], screen)
                self.objs.append(RealObj.Real_Obj_With_Dialog(i['pos'], i['final_pos'], i['player_size'], i['img_path'],
                                                              dialog_group))
                self.index += 1
            elif i['type'] == 'Real_Obj':
                self.objs.append(RealObj.Real_Obj(i['pos'], i['final_pos'], i['player_size'], i['img_path']))

            elif i['type'] == 'SceneChange_Obj':
                self.objs.append(RealObj.SceneChange_Obj(screen, i['pos'], i['final_pos'], i['player_size'], animation))
        return self.objs


if __name__ == '__main__':
    import pygame
    screen = pygame.display.set_mode((500, 500))
    mixer = DialogSceneMixer(real_obj_path='C:\\Users\\pc\\Desktop\\type\\实体文件实例.json',
                             dialog_path='C:\\Users\\pc\\Desktop\\type\\对话文件实例.json')
    mixer.mix(screen=screen)[2].show_dialog()

# ['你选择', ('回去拿', '不管了', '大喊一声"绯红之王"！', '这学校，我不待也罢！')]
# [['你跑回去拿回了饭卡'], ['你轻蔑一笑', '丝毫没有理会，径直离去'], ['绯红之王！', '嗡~', '你惊奇地发现饭卡回到了你身上', '你大吃一惊'],
# ['你的嘴角上扬，成为了歪嘴龙王']])