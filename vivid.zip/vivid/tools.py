import os
import random
import sys
from widgets import Button
import pygame
from PIL import Image

pygame.init()
FONT = pygame.font.Font(
    'C:\\Users\\Administrator\\PycharmProjects\\vivid\\material\\system\\system material\\pixfont.ttf', 20)
KEYS = [
    pygame.K_BACKSPACE,
    pygame.K_TAB,
    pygame.K_CLEAR,
    pygame.K_RETURN,
    pygame.K_PAUSE,
    pygame.K_SPACE,
    pygame.K_EXCLAIM,
    pygame.K_QUOTEDBL,
    pygame.K_HASH,
    pygame.K_DOLLAR,
    pygame.K_AMPERSAND,
    pygame.K_QUOTE,
    pygame.K_LEFTPAREN,
    pygame.K_RIGHTPAREN,
    pygame.K_ASTERISK,
    pygame.K_PLUS,
    pygame.K_COMMA,
    pygame.K_MINUS,
    pygame.K_PERIOD,
    pygame.K_SLASH,
    pygame.K_0,
    pygame.K_1,
    pygame.K_2,
    pygame.K_3,
    pygame.K_4,
    pygame.K_5,
    pygame.K_6,
    pygame.K_7,
    pygame.K_8,
    pygame.K_9,
    pygame.K_COLON,
    pygame.K_SEMICOLON,
    pygame.K_LESS,
    pygame.K_EQUALS,
    pygame.K_GREATER,
    pygame.K_QUESTION,
    pygame.K_AT,
    pygame.K_LEFTBRACKET,
    pygame.K_BACKSLASH,
    pygame.K_RIGHTBRACKET,
    pygame.K_CARET,
    pygame.K_UNDERSCORE,
    pygame.K_BACKQUOTE,
    pygame.K_a,
    pygame.K_b,
    pygame.K_c,
    pygame.K_d,
    pygame.K_e,
    pygame.K_f,
    pygame.K_g,
    pygame.K_h,
    pygame.K_i,
    pygame.K_j,
    pygame.K_k,
    pygame.K_l,
    pygame.K_m,
    pygame.K_n,
    pygame.K_o,
    pygame.K_p,
    pygame.K_q,
    pygame.K_r,
    pygame.K_s,
    pygame.K_t,
    pygame.K_u,
    pygame.K_v,
    pygame.K_w,
    pygame.K_x,
    pygame.K_y,
    pygame.K_z,
    pygame.K_UP,
    pygame.K_DOWN,
    pygame.K_RIGHT,
    pygame.K_LEFT,
]
KEYS_DICT = {
    pygame.K_BACKSPACE: 'backspace',
    pygame.K_TAB: 'tab',
    pygame.K_CLEAR: 'clear',
    pygame.K_RETURN: 'return',
    pygame.K_PAUSE: 'pause',
    pygame.K_SPACE: 'space',
    pygame.K_EXCLAIM: 'exclaim',
    pygame.K_QUOTEDBL: 'quotedbl',
    pygame.K_HASH: '#',
    pygame.K_DOLLAR: '$',
    pygame.K_AMPERSAND: 'ampersand',
    pygame.K_QUOTE: 'quote',
    pygame.K_LEFTPAREN: 'parenthesis',
    pygame.K_RIGHTPAREN: 'parenthesis',
    pygame.K_ASTERISK: 'asterisk',
    pygame.K_KP_PLUS: '+',
    pygame.K_COMMA: ',',
    pygame.K_MINUS: '∑',
    pygame.K_PERIOD: '.',
    pygame.K_SLASH: '/',
    pygame.K_0: '0',
    pygame.K_1: '1',
    pygame.K_2: '2',
    pygame.K_3: '3',
    pygame.K_4: '4',
    pygame.K_5: '5',
    pygame.K_6: '6',
    pygame.K_7: '7',
    pygame.K_8: '8',
    pygame.K_9: '9',
    pygame.K_KP0: '0',
    pygame.K_KP1: '1',
    pygame.K_KP2: '2',
    pygame.K_KP3: '3',
    pygame.K_KP4: '4',
    pygame.K_KP5: '5',
    pygame.K_KP6: '6',
    pygame.K_KP7: '7',
    pygame.K_KP8: '8',
    pygame.K_KP9: '9',
    pygame.K_COLON: 'colon',
    pygame.K_SEMICOLON: 'semicolon',
    pygame.K_LESS: 'less',
    pygame.K_EQUALS: '=',
    pygame.K_GREATER: 'sign',
    pygame.K_QUESTION: 'mark',
    pygame.K_AT: 'at',
    pygame.K_LEFTBRACKET: '[',
    pygame.K_BACKSLASH: '\\',
    pygame.K_RIGHTBRACKET: ']',
    pygame.K_CARET: 'caret',
    pygame.K_UNDERSCORE: '_',
    pygame.K_BACKQUOTE: '~',
    pygame.K_a: 'a',
    pygame.K_b: 'b',
    pygame.K_c: 'c',
    pygame.K_d: 'd',
    pygame.K_e: 'e',
    pygame.K_f: 'f',
    pygame.K_g: 'g',
    pygame.K_h: 'h',
    pygame.K_i: 'i',
    pygame.K_j: 'j',
    pygame.K_k: 'k',
    pygame.K_l: 'l',
    pygame.K_m: 'm',
    pygame.K_n: 'n',
    pygame.K_o: 'o',
    pygame.K_p: 'p',
    pygame.K_q: 'q',
    pygame.K_r: 'r',
    pygame.K_s: 's',
    pygame.K_t: 't',
    pygame.K_u: 'u',
    pygame.K_v: 'v',
    pygame.K_w: 'w',
    pygame.K_x: 'x',
    pygame.K_y: 'y',
    pygame.K_z: 'z',
    pygame.K_UP: 'up',
    pygame.K_DOWN: 'down',
    pygame.K_RIGHT: 'right',
    pygame.K_LEFT: 'left',
}


def resize_img(img_path, new_size):  # (0, 0)
    try:
        img = Image.open(img_path)
        new_img = img.resize(new_size)
        new_img.save('./new_img_w.png')
        img = pygame.image.load('./new_img_w.png')
        os.remove('./new_img_w.png')
        return img
    except ValueError:
        return False


def split_str(size, s):
    split_list = []
    for i in range(0, int(len(s) / size) + 1):
        split_list.append(s[0 + i * size:size + i * size])
    return split_list


def load_imgs(path):
    img_dict = {}
    file_list = os.listdir(path)
    for i in file_list:
        try:
            file_list_new = os.listdir(path + i)
            for ii in file_list_new:
                if ii.split('.')[1] == 'png' or ii.split('.')[1] == 'jpg':
                    img_dict[ii.split('.')[0]] = pygame.image.load(path + i + '/' + ii)
        except NotADirectoryError:
            ...
    return img_dict


class Timer:
    def __init__(self, FPS, time, func, times):
        self.time = time
        self.func = func
        self.re_times = int(FPS * time)
        self.flag_times = self.re_times
        self.times = times

    def update(self):
        self.re_times -= 1
        if self.re_times == 0 and self.times:
            if self.times == 'infinity':
                self.func()
            else:
                self.times -= 1
                self.func()
            self.re_times = self.flag_times


class UpgradesTimer(Timer):
    """
    升级版计时器，可以多加参数并有占位符可以储存数据
    """

    # 60 0.5 -- 5
    def __init__(self, FPS, time, func, times):
        super().__init__(FPS, time, func, times)
        self.flag_times = times
        self.flag_re_times = int(FPS * time)
        self.flag_times = self.re_times
        self.flag = None

    def update_new(self, args):
        self.re_times -= 1
        if self.re_times == 0 and self.times:
            if self.times == 'infinity':
                self.func(args)
            else:
                self.times -= 1
                self.func(args)
            self.re_times = self.flag_times

    def stop(self):
        self.times = 0

    def reset(self):
        self.re_times = self.flag_re_times
        self.flag_times = self.flag_re_times
        self.times = self.flag_times


def check_in_rect(mouse_pos, rect_pos_s, rect_pos_f):
    if rect_pos_s[0] < mouse_pos[0] < rect_pos_f[0] and rect_pos_s[1] < mouse_pos[1] < rect_pos_f[1]:
        return True


flag = True


def show_error(screen, text, position, font, pos_):
    """
    显示错误
    :param screen:屏幕对象
    :param text: 错误文字
    :param position: 函数位置文字
    :param font: 字体对象
    :param pos_: 错误位置坐标
    :return: None
    """
    global flag, gensui
    # (self, pos, text, text_color, choose_img_path, img_path, font, args=list)
    pos = pos_
    button = Button.Button((pos[0] + 390, pos[1] + 110), '确定', (0, 0, 0), 'system/system material/1234.jpg',
                           'system/system material/choose_button.png',
                           font)
    text_err = font.render(text, False, (255, 0, 0))
    position_err = font.render(position, False, (255, 0, 0))
    error_img = pygame.image.load('material/system/system material/error_img.png')

    def button_yes(arg=list):
        global flag
        flag = False

    button.bind(button_yes)

    while flag:
        pos_mouse = pygame.mouse.get_pos()
        screen.blit(error_img, pos)
        screen.blit(position_err, (pos[0] + 20, pos[1] + 30))
        screen.blit(text_err, (pos[0] + 90, pos[1] + 60))
        button.blit_button(pos_mouse, screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                button.button_click(pos_mouse)
        pygame.display.update()
    flag = True


def draw_text(text, position, screen, color=(255, 255, 255)):
    text_r = FONT.render(text, False, color)
    screen.blit(text_r, position)


def draw_name_and_head(name, head_img, screen):
    screen.blit(head_img, (20, 390))
    name_r = FONT.render(name, False, (255, 255, 255))
    screen.blit(name_r, (14, 465))


def draw_choices(text, screen):
    draw_text(text[0], (18, 380), screen)
    for index, i in enumerate(text[1]):
        if index <= 1:
            draw_text(i, (25 + 240 * index, 415), screen)
        else:
            draw_text(i, (25 + 240 * (index - 2), 445), screen)


def crop_img(img_path, start, final):
    img = Image.open(img_path)
    img2 = img.crop((start[0], start[1], final[0], final[1]))
    return img2


def crop_student(img_name):
    student_imgs = []
    for i in range(0, 5):
        student_one = []
        for ii in range(0, 5):
            student_one.append(crop_img(img_name, (32 * ii, 48 * ii), (32 + 32 * ii, 48 + 48 * ii)))
        student_imgs.append(student_one)
    return student_imgs


def True_False_converter(list_):
    new_list = []
    for i in list_:
        new_list.append(bool(i))
    return new_list


def True_False_creator(length, t_or_f):
    list_ = []
    if t_or_f:
        for i in range(int(length)):
            list_.append(True)
    else:
        for i in range(int(length)):
            list_.append(False)
    return list_


def create_result_for_probability(probability):
    cardinal_number = pow(10, len(str(probability).split('.')[1]))
    probability = float(probability) * cardinal_number
    if 0 <= random.randint(0, cardinal_number) <= probability:
        return True
    else:
        return False


def check_point_in_rect(start, final, point) -> bool:
    """
    检测点是否在矩形内部
    :param start: 矩形起始点
    :param final:矩形终结点
    :param point:被检测点
    :return:bool
    """
    if start[0] < point[0] < final[0] and start[1] < point[1] < final[1]:
        return True
    else:
        return False


def check_two_rect_intersect(rect1, rect2, type_=True):
    """
    rect1请尽量传入rect2小的矩形，为了性能考虑
    另；此种方法仅适用于检测运动物体，对于静止的一些个例失效
    Type_:是否开启高精度检测，不开启的话若子弹大于敌人可能检测不准
    """
    points_1 = [[rect1[0], rect1[1]],
                [rect1[2], rect1[1]],
                [rect1[2], rect1[3]],
                [rect1[0], rect1[3]]]
    points_2 = [[rect2[0], rect2[1]],
                [rect2[2], rect2[1]],
                [rect2[2], rect2[3]],
                [rect2[0], rect2[3]]]
    for i in points_1:
        if check_in_rect(i, [rect2[0], rect2[1]], [rect2[2], rect2[3]]):
            return True
    if type_:
        for i in points_2:
            if check_in_rect(i, [rect1[0], rect1[1]], [rect1[2], rect1[3]]):
                return True
    else:
        return False


def str_insert(str_origin, pos, str_add):
    str_list = list(str_origin)    # 字符串转list
    str_list.insert(pos, str_add)  # 在指定位置插入字符串
    str_out = ''.join(str_list)    # 空字符连接
    return  str_out


if __name__ == '__main__':
    def update_func(args):
        args.flag += 1
        print(args.flag)


    t1 = UpgradesTimer(60, 0.3, update_func, 5)
    t1.flag = 0

    clock = pygame.time.Clock()
    while t1.flag < 5:
        clock.tick(60)
        t1.update_new(t1)
