import pygame
from element import RealObj
from initiator import errors
import tools
from widgets import Button


class ArticleShelf:
    """
    物品格对象，方法：widget_update；bind_obj；widget_click_update；
    """

    def __init__(self, pos, size, img_path, choose_img_path, click_img, screen):
        self.pos = pos
        self.final_pos = [pos[0] + size[0], pos[1] + size[1]]
        self.img = RealObj.resize_img(img_path, [0, 0, size[0], size[1]])
        self.choose_img = RealObj.resize_img(choose_img_path, [0, 0, size[0], size[1]])
        self.click_img = RealObj.resize_img(click_img, [0, 0, size[0], size[1]])
        self.now_img = self.img
        self.screen = screen

        self.obj = None

    def _choose(self, mouse_pos):
        """
        内部私有方法，用于检测鼠标并更改格子背景图片
        |被循环|
        :param mouse_pos: mousePOS
        :return: None
        """
        if RealObj.check_point_in_rect(self.pos, self.final_pos, mouse_pos):
            self.now_img = self.choose_img
        else:
            self.now_img = self.img

    def widget_update(self, mouse_pos, inventory):
        """
        画出格子背景，物品图片
        |被循环|
        :param mouse_pos: mousePOS
        :return: None
        """
        self.screen.blit(self.now_img, self.pos)
        if self.obj is not None:
            self.screen.blit(self.obj.img, self.pos)
            self.obj.article_update(self.screen, mouse_pos, self.pos, self.final_pos, inventory)
        self._choose(mouse_pos)

    def bind_obj(self, obj):
        """
        绑定物品对象
        |单次执行|
        :param obj:物品对象
        :return: None
        """
        self.obj = obj

    def widget_click_update(self, mouse_pos, type_):
        """
        按键后的更新
        |单次执行|
        """
        if self.obj is not None:
            self.obj.click_update(mouse_pos)
            if RealObj.check_point_in_rect(self.pos, self.final_pos, mouse_pos) and self.obj.action_alive:
                self.now_img = self.click_img
                if type_ == 1:
                    self.obj.start_show_description(self.pos, self.final_pos, mouse_pos)
                elif type_ == 2:
                    self.obj.start_show_actions(self.pos, self.final_pos, mouse_pos)
            else:
                self.now_img = self.img
                try:
                    if self.obj.action_alive:
                        self.obj.action_alive = False
                except AttributeError:
                    ...

    def reset_obj(self):
        self.obj = None


class Article:
    """
    物品对象，用于和物品格对象共同使用；
    （注意：在添加物品时请在外面套上一层克隆函数，否则会因为原对象的更改导致错误！）
    """

    def __init__(self, img_path, size, description, describe_img_path, font, name, color=(0, 0, 0), anti_aliasing=False,
                 font_size=20):
        self.font = font
        self.img = RealObj.resize_img(img_path, [0, 0, size[0], size[1]])
        self.description = tools.split_str(10, description)
        self.font_Size = font_size
        self.name = name
        self.num = 1

        des = []
        for a in self.description:
            des.append(font.render(a, anti_aliasing, color))
        self.description = des
        self.description.append(font.render(name, anti_aliasing, (0, 0, 255)))
        self.description.append(font.render('数量:' + str(self.num), anti_aliasing, (0, 0, 255)))

        self.describe_img = RealObj.resize_img(describe_img_path,
                                               [0, 0, 10 * self.font_Size, (len(self.description) + 1) * font_size])
        self.interface_buttons_list = None
        self.action_alive = False
        self.description_alive = False
        self.new_pos = [0, 0]

    def bind_buttons(self, button_list):
        """
        绑定按钮列表组
        |单次执行|
        :param button_list: 列表组对象
        :return: NOne
        """
        self.interface_buttons_list = button_list

    def start_show_actions(self, start_pos, final_pos, mouse_pos):
        """
        设置列表组和元对象的标志位为TRUE
        |单次执行|
        :return: None
        """
        if RealObj.check_point_in_rect(start_pos, final_pos, mouse_pos):
            self.interface_buttons_list.if_alive = True
            self.action_alive = True

    def stop_show_actions(self):
        """
        设置列表组和元对象的标志位为FALSE
        |单次执行|
        :return: None
        """
        self.interface_buttons_list.if_alive = False
        self.action_alive = False

    def start_show_description(self, start_pos, final_pos, mouse_pos):
        """
        设置元对象的描述标志位为TRUE
        |单次执行|
        :return: None
        """
        if RealObj.check_point_in_rect(start_pos, final_pos, mouse_pos):
            self.description_alive = True

    def stop_show_description(self):
        """
        设置元对象的描述标志位为FALSE
        |单次执行|
        :return: None
        """
        self.description_alive = False

    def _show_description(self, screen, pos_, inventory):
        """
        内部私有方法，用于显示描述
        |自循环|
        """
        pos = [pos_[0], pos_[1]]
        if pos_[0] + 200 > 500:
            pos[0] -= 200
        self.description.remove(self.description[-1])
        self.description.append(self.font.render('数量:' + str(self.num), False, (0, 0, 255)))
        while self.description_alive:
            for i in inventory.article_shelf:
                inventory.screen.blit(i.now_img, i.pos)
                try:
                    inventory.screen.blit(i.obj.img, i.pos)
                except AttributeError:
                    ...
            screen.blit(self.describe_img, pos)
            for index, b in enumerate(self.description):
                screen.blit(b, (pos[0], pos[1] + index * self.font_Size))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.description_alive = False
            pygame.display.update()

    def _show_actions(self, screen, inventory):
        """
        显示按钮列表组
        |自循环|
        """
        # self.interface_buttons_list.blit_buttons(mouse_pos, screen)
        while self.action_alive:
            for i in inventory.article_shelf:
                inventory.screen.blit(i.now_img, i.pos)
                try:
                    inventory.screen.blit(i.obj.img, i.pos)
                except AttributeError:
                    ...
            mouse_pos = pygame.mouse.get_pos()
            self.interface_buttons_list.blit_buttons(mouse_pos, screen)
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_s:
                        self.interface_buttons_list.if_alive = True
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.interface_buttons_list.buttons_click(mouse_pos)
                    self.action_alive = False
                elif event.type == pygame.QUIT:
                    pygame.quit()
            pygame.display.update()

    def article_update(self, screen, mouse_pos, start_pos, final_pos, inventory):
        """
        物品刷新方法
        |被循环|含有阻塞方法|
        """
        if self.action_alive:
            self._show_actions(screen, inventory)
        if self.description_alive and RealObj.check_point_in_rect(start_pos, final_pos, mouse_pos):
            self._show_description(screen, mouse_pos, inventory)

    def click_update(self, mouse_pos):
        """
        按键刷新方法
        """
        self.interface_buttons_list.buttons_click(mouse_pos)

    def change_pos_of_buttons(self, new_pos):
        """
        改变按钮坐标，使其可以随鼠标的位置移动
        """
        self.new_pos = new_pos
        self.interface_buttons_list.reset_pos(new_pos)


class Inventory:
    """
    物品栏对象，可包含众多物品格
    方法：
    _init_article_shelf 内部初始化背包格
    widgets_update 刷新控件
    widgets_click_update 点击刷新
    append_article 添加物品
    delete_article 删除物品
    """

    def __init__(self, size, pos, grid_size, interval, img_path, choose_img_path, click_img_path, screen, bg_path,
                 crosswise=True, all_bg_path=None):
        self.flag = True

        self.size = size  # 写出?x?的背包结构
        self.crosswise = crosswise
        self.img_path = img_path
        self.screen = screen
        if bg_path:
            self.bg_img = RealObj.resize_img(bg_path, [0, 0, size[0] * (interval + grid_size[0]),
                                                       size[1] * (interval + grid_size[1])])
        else:
            self.bg_img = None
        self.click_img_path = click_img_path
        self.choose_img_path = choose_img_path
        self.interval = interval  # 各自之间的间隔
        self.grid_size = grid_size  # 格子的大小
        self.pos = pos
        self.article_shelf = []
        self._init_article_shelf()
        self.article_shelf_obj = tools.True_False_converter([i.obj for i in self.article_shelf])

        self.button_group = None
        if all_bg_path:
            self.all_bg = RealObj.resize_img(img_path, [0, 0, 500, 500])
        else:
            self.all_bg = None

    def _init_article_shelf(self):
        """
        内部私有方法，用于初始化物品格列表
        :return: None
        """
        if self.crosswise:
            for i in range(0, self.size[1]):
                for ii in range(0, self.size[0]):
                    self.article_shelf.append(ArticleShelf(
                        [self.pos[0] + ii * (self.grid_size[0] + self.interval),
                         self.pos[1] + i * (self.grid_size[1] + self.interval)], self.grid_size
                        , self.img_path, self.choose_img_path, self.click_img_path, self.screen
                    ))
        else:
            for i in range(0, self.size[0]):
                for ii in range(0, self.size[1]):
                    self.article_shelf.append(ArticleShelf(
                        [self.pos[0] + i * (self.grid_size[0] + self.interval),
                         self.pos[1] + ii * (self.grid_size[1] + self.interval)], self.grid_size
                        , self.img_path, self.choose_img_path, self.click_img_path, self.screen
                    ))

    def widgets_update(self, mouse_pos):
        """
        刷新控件方法
        """
        if self.bg_img:
            self.screen.blit(self.bg_img, self.pos)
        if self.all_bg:
            self.screen.blit(self.all_bg, (0, 0))
        self.article_shelf_obj = tools.True_False_converter([i.obj for i in self.article_shelf])
        for i in self.article_shelf:
            i.widget_update(mouse_pos, self)
        if self.button_group:
            self.button_group.blit_buttons(mouse_pos, self.screen)

    def widgets_click_update(self, mouse_pos, mouse_pressed):
        """
        按键检测方法
        |单次执行|
        """
        if mouse_pressed[0]:
            for i in self.article_shelf:
                if i.obj is not None:
                    if not i.obj.action_alive:
                        i.obj.start_show_description(i.pos, i.final_pos, mouse_pos)
                    i.widget_click_update(mouse_pos, 1)
            if self.button_group:
                self.button_group.buttons_click(mouse_pos)
        else:
            for i in self.article_shelf:
                if i.obj is not None:
                    i.obj.change_pos_of_buttons(mouse_pos)
                    i.obj.start_show_actions(i.pos, i.final_pos, mouse_pos)
                    i.widget_click_update(mouse_pos, 2)

    def append_article(self, kelong_article):
        """
        添加物品，需添加克隆函数下的物品对象
        :param kelong_article: 克隆的物品对象，不可更改原对象
        :return: None
        """
        for index, i in enumerate(self.article_shelf):
            if i.obj is None:
                self.article_shelf[index].bind_obj(kelong_article)
                return
            elif i.obj.name == kelong_article.name:
                try:
                    if not i.obj.uniqueness:  # 非唯一性实体
                        i.obj.num += 1
                        return
                    else:
                        for index_, i_ in enumerate(self.article_shelf):
                            if i_.obj is None:
                                self.article_shelf[index_].bind_obj(kelong_article)
                                return
                except AttributeError:  # 非唯一性实体
                    i.obj.num += 1
                    return
        raise errors.VividError(code=10003, status='背包上限溢出！')

    def delete_article(self, article_name):
        """
        删除对象并检测数量，若数量低于0，则删除总对象
        :param article_name:
        :return:
        """
        for i in self.article_shelf:
            if i.obj is not None:
                if i.obj.name != article_name:
                    continue
                else:
                    i.obj.num -= 1
                    if i.obj.num <= 0:
                        i.reset_obj()
                    return
            else:
                break
        raise errors.VividError(code=10004, status='找不到名为\"' + article_name + '\"的实体')

    def bind_button_group(self, button_group_obj):
        self.button_group = button_group_obj

    def inventory_mainloop(self):
        while self.flag:
            mouse_pos_ = pygame.mouse.get_pos()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pressed_ = pygame.mouse.get_pressed()
                    self.widgets_click_update(mouse_pos_, mouse_pressed_)
            self.widgets_update(mouse_pos_)
            pygame.display.update()


class UniquenessArticle(Article):
    """
    唯一性的物体，无法堆叠
    """

    def __init__(self, img_path, size, description, describe_img_path, font, name, color=(0, 0, 0), anti_aliasing=False,
                 font_size=20):
        super().__init__(img_path, size, description, describe_img_path, font, name, color=color,
                         anti_aliasing=anti_aliasing, font_size=font_size)
        self.uniqueness = True
        self.description.remove(self.description[-1])

    def _show_description(self, screen, pos_, inventory):
        """
        内部私有方法，用于显示描述
        |自循环|
        """
        pos = [pos_[0], pos_[1]]
        if pos_[0] + 200 > 500:
            pos[0] -= 200
        while self.description_alive:
            for i in inventory.article_shelf:
                inventory.screen.blit(i.now_img, i.pos)
                try:
                    inventory.screen.blit(i.obj.img, i.pos)
                except AttributeError:
                    ...
            screen.blit(self.describe_img, pos)
            for index, b in enumerate(self.description):
                screen.blit(b, (pos[0], pos[1] + index * self.font_Size))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.description_alive = False
            pygame.display.update()


class CustomArticle(Article):
    """
    自定义的物体，功能属性更丰富
    """

    def __init__(self, img_path, size, description, describe_img_path, font, name, color=(0, 0, 0), anti_aliasing=False,
                 font_size=20, attribute_dict=None, uniqueness=False):
        super().__init__(img_path, size, description, describe_img_path, font, name, color=color,
                         anti_aliasing=anti_aliasing, font_size=font_size)
        if attribute_dict is None:
            attribute_dict = {}
        self.uniqueness = uniqueness
        if self.uniqueness:
            self.description.remove(self.description[-1])
        self.attribute_dict = attribute_dict
        if len(self.attribute_dict):
            for i in self.attribute_dict.keys():
                self.description.append(self.font.render(i + ':' + str(self.attribute_dict[i]), False, (0, 0, 255)))

    def _show_description(self, screen, pos_, inventory):
        """
        内部私有方法，用于显示描述
        |自循环|
        """
        pos = [pos_[0], pos_[1]]
        if pos_[0] + 200 > 500:
            pos[0] -= 200
        if not self.uniqueness:
            self.description.remove(self.description[-1])
            self.description.append(self.font.render('数量:' + str(self.num), False, (0, 0, 255)))
        while self.description_alive:
            for i in inventory.article_shelf:
                inventory.screen.blit(i.now_img, i.pos)
                try:
                    inventory.screen.blit(i.obj.img, i.pos)
                except AttributeError:
                    ...
            screen.blit(self.describe_img, pos)
            for index, b in enumerate(self.description):
                screen.blit(b, (pos[0], pos[1] + index * self.font_Size))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.description_alive = False
            pygame.display.update()


class LimitedArticleShelf(ArticleShelf):
    """
    带有标识权限的物品格，只允许特定的物品存储
    """

    def __init__(self, pos, size, img_path, choose_img_path, click_img, screen, limit):
        super().__init__(pos, size, img_path, choose_img_path, click_img, screen)
        self.limit = limit

    def bind_obj(self, obj):
        if self.limit != 'all':
            if obj.limit != self.limit:
                raise errors.VividError(code=10006, status='标识权限错误')
            else:
                self.obj = obj
        else:
            self.obj = obj


class UniquenessLimitedArticleShelf(LimitedArticleShelf):
    def __init__(self, pos, size, img_path, choose_img_path, click_img, screen, limit):
        super().__init__(pos, size, img_path, choose_img_path, click_img, screen, limit)

    def bind_obj(self, obj):
        if obj.limit != self.limit and self.limit != 'all':
            raise errors.VividError(code=10006, status='标识权限错误')
        if not obj.uniqueness:
            raise errors.VividError(code=10007, status='绑定物品错误')
        else:
            self.obj = obj


class LimitArticle(Article):
    def __init__(self, limit_type, img_path, size, description, describe_img_path, font, name, color=(0, 0, 0),
                 anti_aliasing=False,
                 font_size=20):
        super().__init__(img_path, size, description, describe_img_path, font, name, color=color,
                         anti_aliasing=anti_aliasing,
                         font_size=font_size)
        self.limit = limit_type


class CustomLimitInventory(Inventory):
    def __init__(self, size, pos, grid_size, interval, limit_list, img_path, choose_img_path, click_img_path, screen,
                 bg_path,
                 crosswise=True):
        self.limit_list = limit_list
        super().__init__(size, pos, grid_size, interval, img_path, choose_img_path, click_img_path, screen, bg_path,
                         crosswise=crosswise)

    def _init_article_shelf(self):
        index = 0
        if self.crosswise:
            for i in range(0, self.size[1]):
                for ii in range(0, self.size[0]):
                    self.article_shelf.append(LimitedArticleShelf(
                        [self.pos[0] + ii * (self.grid_size[0] + self.interval),
                         self.pos[1] + i * (self.grid_size[1] + self.interval)], self.grid_size
                        , self.img_path, self.choose_img_path, self.click_img_path, self.screen,
                        limit=self.limit_list[index]
                    ))
                    index += 1
        else:
            for i in range(0, self.size[0]):
                for ii in range(0, self.size[1]):
                    self.article_shelf.append(LimitedArticleShelf(
                        [self.pos[0] + i * (self.grid_size[0] + self.interval),
                         self.pos[1] + ii * (self.grid_size[1] + self.interval)], self.grid_size
                        , self.img_path, self.choose_img_path, self.click_img_path, self.screen,
                        limit=self.limit_list[index]
                    ))
                    index += 1


def shallow_copy(a):
    """
    克隆函数，在不损伤原对象的情况下返回一个全新的对象
    无需担心原对象被更改造成的错误，且克隆的新对象会被
    Python垃圾回收机制处理，创建的新对象会在用完后被
    销毁
    :param a: 原对象
    :return: 克隆后的新对象
    """
    n_a = a
    return n_a


if __name__ == '__main__':
    path = 'C:\\Users\\pc\\Desktop\\type\\'
    screen_ = pygame.display.set_mode((500, 500))
    a1 = Article(path + 'item.png', [50, 50], '这是一个山的雕塑，你要是坚持认为它是一个中指我也没有办法', path + 'di.png', tools.FONT,
                 '一个雕塑')
    a2 = UniquenessArticle(path + 'item.png', [50, 50], '这才是中指', path + 'di.png', tools.FONT,
                           '一个中指')
    a3 = CustomArticle(path + 'item.png', [50, 50], '这是一个拥有毁天灭地力量的神器，中间凸起的部分便是攻击的地方，你侧耳听取，里面仿佛有一个声音在喊到“木叶体术奥义，千年杀！”',
                       path + 'di.png', tools.FONT,
                       '无上神器', uniqueness=True, anti_aliasing=False, attribute_dict={'能量': 100, '杀敌数': 0})

    mibl1 = Button.MonotonyInterfaceButtonList((100, 100), [150, 20],
                                               ['丢弃', '使用'],
                                               (0, 0, 0), 'C:\\Users\\pc\\Desktop\\type\\cmil.png',
                                               'C:\\Users\\pc\\Desktop''\\type\\mil.png', tools.FONT, 20)
    mibl2 = Button.MonotonyInterfaceButtonList((155, 100), [150, 20],
                                               ['丢弃', '使用', '调查', '更换姿势', '千年杀！'],
                                               (0, 0, 0), 'C:\\Users\\pc\\Desktop\\type\\cmil.png',
                                               'C:\\Users\\pc\\Desktop''\\type\\mil.png', tools.FONT, 20)
    mibl3 = Button.MonotonyInterfaceButtonList((210, 100), [150, 20],
                                               ['丢弃', '使用', '调查', '更改', '毁天灭地'],
                                               (0, 0, 0), 'C:\\Users\\pc\\Desktop\\type\\cmil.png',
                                               'C:\\Users\\pc\\Desktop''\\type\\mil.png', tools.FONT, 20)

    button_group1 = Button.ButtonGroup(
        [Button.Interface_Button([0, 450, 100, 30], '', (0, 0, 0), path + 'c_interface_button.png',
                                 path + 'interface_button.png', tools.FONT, 20),
         Button.Interface_Button([120, 450, 100, 30], '', (0, 0, 0), path + 'c_interface_button.png',
                                 path + 'interface_button.png', tools.FONT, 20),
         Button.Interface_Button([240, 450, 100, 30], '', (0, 0, 0), path + 'c_interface_button.png',
                                 path + 'interface_button.png', tools.FONT, 20),
         Button.Interface_Button([360, 450, 100, 30], '', (0, 0, 0), path + 'c_interface_button.png',
                                 path + 'interface_button.png', tools.FONT, 20)]
    )


    def f1(param):
        print('f1')


    def f2(param):
        print('f2')


    def f3(param):
        print('f3')


    def f4(param):
        print('f4')


    def f5(param):
        print('f5')


    mibl1.bind_interface_buttons_funcs([f1, f2, ])
    mibl2.bind_interface_buttons_funcs([f1, f2, f3, f4, f5])
    mibl3.bind_interface_buttons_funcs([f1, f2, f3, f4, f5])
    a1.bind_buttons(mibl1)
    a2.bind_buttons(mibl2)
    a3.bind_buttons(mibl3)

    inv1 = Inventory([8, 4], (26, 0), [50, 50], 3, path + 'article_shelf.png', path + 'c_article_shelf.png',
                     path + 'click_article_shelf.png', screen_, path + 'bpbg.png')

    inv1.inventory_mainloop()
