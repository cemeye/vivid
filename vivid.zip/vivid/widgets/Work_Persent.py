import pygame
import time


pygame.init()


class Work_Persent:
    def __init__(self, color, lenth, pos, width, init_size, text_and_color, font):
        self.color = color
        self.lenth = lenth
        self.pos = pos
        self.text = text_and_color[0]
        self.text_render = font.render(text_and_color[0], False, text_and_color[1])
        self.width = width
        self.size = init_size

    def add(self, num):
        self.size += num

    def cut(self, num):
        self.size -= num

    def set(self, num):
        self.size = num

    def set_pos(self, new_pos):
        self.pos = new_pos

    def set_color(self, new_color):
        self.color = new_color

    def blit_work_persent(self, screen_):
        screen_.blit(self.text_render, (self.pos[0] - len(self.text) * 10 - 20, self.pos[1] - 3))
        if self.size > self.lenth:
            self.size = self.lenth
        elif self.size < 0:
            self.size = 0
        pygame.draw.rect(screen_, self.color, (self.pos[0], self.pos[1] + 3, self.size, self.width))


# wp = Work_Persent((255, 0, 0), 100, (50, 10), 10, 200, ("血量:", (255, 255, 255)), font)

class Gradient_progress_bar(Work_Persent):
    def __init__(self, color, lenth, pos, width, init_size, text_and_color, font, screen):
        super().__init__(color, lenth, pos, width, init_size, text_and_color, font)
        self.flag_size = 0
        self.screen = screen

    def add(self, num):
        self.flag_size = self.size + num
        while self.size < self.flag_size <= self.lenth:
            self.size += 1
            time.sleep(0.01)
            self.blit_work_persent(self.screen)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
            pygame.display.update()

    def cut(self, num):
        self.flag_size = self.size - num
        while self.size > self.flag_size >= 0:
            self.size -= 1
            time.sleep(0.01)
            self.screen.fill((0, 0, 0))
            self.blit_work_persent(self.screen)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
            pygame.display.update()


if __name__ == '__main__':
    wp = Gradient_progress_bar((255, 0, 0), 100, (50, 10), 10, 200, ("血量:", (255, 255, 255)), font, screen)
    while True:
        wp.blit_work_persent(screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    wp.cut(50)
                elif event.key == pygame.K_a:
                    wp.add(5)
        pygame.display.update()
