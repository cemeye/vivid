import pygame
import tools
from element import RealObj
from initiator import errors
from widgets import Button
import Work_Persent
import inventory


class Item_Interface:
    """
    装备栏，自定义装备个数
    """

    def __init__(self, bg_img_path, player_img, article_num, article_img, article_choose_img, article_click_img,
                 screen, limit_list, all_bg_img_path=None):
        self.flag = True

        self.screen = screen
        self.pos = (0, 0)
        self.size = (300, 400)
        self.bg_img = RealObj.resize_img(bg_img_path, [0, 0, 300, 400])
        self.player_img = RealObj.resize_img(player_img, [0, 0, 150, 225])
        self.num = article_num
        self.article_img = article_img
        self.article_choose_img = article_choose_img
        self.article_click_img = article_click_img
        self.inventory = None
        self.limit_list = limit_list
        if all_bg_img_path:
            self.all_bg_img = RealObj.resize_img(all_bg_img_path, [0, 0, 500, 500])
        else:
            self.all_bg_img = None
        if len(self.limit_list) != self.num:
            raise errors.VividError(code=10008, status='权限个数与装备格数不匹配！')

        self._init_inventory()

        self.progress_bar = []
        self.show_text = []
        self.name = []
        self.button_group = None

        self.buff = []

    def _init_inventory(self):
        # size, pos, grid_size, interval, limit_list, img_path, choose_img_path, click_img_path, screen,
        # bg_path,
        # crosswise = True
        self.inventory = inventory.CustomLimitInventory(
            [1, self.num],
            [240, 16],
            [50, 50],
            16,
            self.limit_list,
            self.article_img,
            self.article_choose_img,
            self.article_click_img,
            self.screen,
            None,
            crosswise=False
        )

    def _draw_player(self):
        self.screen.blit(self.player_img, (40, 87))

    def _draw_bg(self):
        if self.all_bg_img:
            self.screen.blit(self.all_bg_img, (0, 0))
        self.screen.blit(self.bg_img, (0, 0))

    def update_all(self, mouse_pos):
        self._draw_bg()
        self._draw_player()
        self.inventory.widgets_update(mouse_pos)
        if len(self.buff):
            for index, i in enumerate(self.buff):
                self.screen.blit(i.buff_img, [10 + index * 40 + 2, 10])
        if len(self.progress_bar):
            for i in self.progress_bar:
                i.blit_work_persent(self.screen)
        if len(self.show_text):
            for index, i in enumerate(self.show_text):
                self.screen.blit(i, (305, len(self.progress_bar) * 16 + index * 20 + 30))
        if len(self.name):
            for index, i in enumerate(self.name):
                self.screen.blit(i, (40, 322 + index * 20))

        if self.button_group:
            self.button_group.blit_buttons(mouse_pos, self.screen)

    def update_click(self, mouse_pos, mouse_pressed):
        self.inventory.widgets_click_update(mouse_pos, mouse_pressed)
        if self.button_group:
            self.button_group.buttons_click(mouse_pos)

    def bind_progress_bar(self, progress_bars):
        self.progress_bar = progress_bars

    def bind_texts(self, texts, font, color=(255, 255, 255)):
        for i in texts:
            self.show_text.append(font.render(i, False, color))

    def bind_names(self, names, font, color=(255, 255, 255)):
        for i in names:
            self.name.append(font.render(i, False, color))

    def bind_button_group(self, button_group):
        self.button_group = button_group

    def item_interface_mainloop(self):
        while self.flag:
            mouse_pos_ = pygame.mouse.get_pos()
            self.update_all(mouse_pos_)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pressed_ = pygame.mouse.get_pressed()
                    self.update_click(mouse_pos_, mouse_pressed_)
            pygame.display.update()


if __name__ == '__main__':
    path = 'C:\\Users\\pc\\Desktop\\type\\'
    screen_ = pygame.display.set_mode((500, 500))
    ib1 = Item_Interface(path + 'ibbg.png', path + 'pli.png', 6, path + 'article_shelf.png', path + 'c_article_shelf'
                                                                                                    '.png',
                         path + 'click_article_shelf.png', screen_, ['头', '胸', '裤', '鞋', '武器', '弹药'],
                         all_bg_img_path=path + 'all_bg_img.png')
    ib1.bind_progress_bar(
        [Work_Persent.Work_Persent((255, 0, 0), 100, (355, 16), 10, 200, ("血量:", (255, 255, 255)), tools.FONT),
         Work_Persent.Work_Persent((0, 0, 255), 100, (355, 38), 10, 200, ("蓝量:", (255, 255, 255)), tools.FONT)])
    ib1.bind_texts(['呵呵呵:', '去你码的', '老子不愿意打电话', '为么逼着我打'], tools.FONT)
    ib1.bind_names(["名称:牛逼之人", "格言：我是个程序员"], tools.FONT, color=(255, 255, 125))
    button_group1 = Button.ButtonGroup(
        [Button.Interface_Button([0, 450, 100, 30], '', (0, 0, 0), path + 'c_interface_button.png',
                                 path + 'interface_button.png', tools.FONT, 20, args=ib1),
         Button.Interface_Button([120, 450, 100, 30], '', (0, 0, 0), path + 'c_interface_button.png',
                                 path + 'interface_button.png', tools.FONT, 20, args=ib1),
         Button.Interface_Button([240, 450, 100, 30], '', (0, 0, 0), path + 'c_interface_button.png',
                                 path + 'interface_button.png', tools.FONT, 20, args=ib1),
         Button.Interface_Button([360, 450, 100, 30], '', (0, 0, 0), path + 'c_interface_button.png',
                                 path + 'interface_button.png', tools.FONT, 20, args=ib1)]
    )


    def print1(args):
        args.flag = False


    button_group1.bind_funcs([print1, print1, print1, print1])
    ib1.bind_button_group(button_group1)

    ib1.item_interface_mainloop()
