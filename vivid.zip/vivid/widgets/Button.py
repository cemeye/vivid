import pygame
from PIL import Image
from initiator import errors
import tools
import os


class Button:
    def __init__(self, pos, text, text_color, choose_img_path, img_path, font, args=list):
        """
        按钮类，需绑定函数体 \n
        :param pos: 按钮位置
        :param text: 按钮上显示的文字
        :param text_color: 文字颜色RGB元组
        :param choose_img_path: 鼠标移动到上方时按钮图片
        :param img_path:正常情况下的按钮图片
        :param font:字体对象
        :param args:可能的函数参数
        """
        self.choose_img = choose_img_path
        self.rect = (pos[0], pos[1], len(text) * 20 + 10, 35)  # x,y,long,width
        self.text = font.render(text, False, text_color)
        self.img = img_path
        self.args = args
        self.resize_img()
        self.show_img = self.img
        self.func = None

    def resize_img(self) -> None:
        """
        裁剪图片，令按钮图片与尺寸合适
        :return: None
        """
        img = Image.open(self.img)
        new_img = img.resize((self.rect[2], self.rect[3]))
        new_img.save('./new_img.png')
        self.img = pygame.image.load('./new_img.png')
        os.remove('./new_img.png')
        c_img = Image.open(self.choose_img)
        new_img = c_img.resize((self.rect[2], self.rect[3]))
        new_img.save('./new_img.png')
        self.choose_img = pygame.image.load('./new_img.png')
        os.remove('./new_img.png')

    def bind(self, func):
        """
        绑定函数
        :param func:函数体
        :return: None
        """
        self.func = func

    def blit_button(self, mouse_pos, screen):
        """
        在屏幕上画出按钮
        :param mouse_pos: 鼠标坐标
        :param screen: 屏幕对象
        :return: None
        """
        if self.rect[0] < mouse_pos[0] < self.rect[0] + self.rect[2] and self.rect[1] < mouse_pos[1] < self.rect[1] + \
                self.rect[3]:
            self.show_img = self.choose_img
        else:
            self.show_img = self.img
        screen.blit(self.show_img, (self.rect[0], self.rect[1]))
        screen.blit(self.text, (self.rect[0] + 5, self.rect[1] + 5))

    def button_click(self, mouse_pos):
        """
        当按下时，传入鼠标坐标，判断是否被按下，调用函数体
        :param mouse_pos: 鼠标坐标元组
        :return: None
        """
        if self.rect[0] < mouse_pos[0] < self.rect[0] + self.rect[2]:
            if self.rect[1] < mouse_pos[1] < self.rect[1] + self.rect[3]:
                self.func(self.args)
                print('调用按钮函数！')


class Interface_Button:
    def __init__(self, rect, text, text_color, choose_img_path, img_path, font, font_size, args=None):
        """
            按钮类，需绑定函数体 \n
            :param rect: 按钮位置与大小  ->(start_pos,final_pos)
            :param text: 按钮上显示的文字
            :param text_color: 文字颜色RGB元组
            :param choose_img_path: 鼠标移动到上方时按钮图片
            :param img_path:正常情况下的按钮图片
            :param font:字体对象
            :param args:可能的函数参数
            """
        self.choose_img = choose_img_path
        self.long = rect[2]
        self.width = rect[3]
        self.pos = (rect[0], rect[1], rect[0] + rect[2], rect[1] + rect[3])
        self.text_size = len(text)
        self.font_size = font_size
        self.rect = self._align_center(rect[2], rect[3])
        self.text = font.render(text, False, text_color)
        self.img = img_path
        self.args = args
        self.resize_img()
        self.show_img = self.img
        self.func = None

    def resize_img(self) -> None:
        """
            裁剪图片，令按钮图片与尺寸合适
            :return: None
            """
        img = Image.open(self.img)
        new_img = img.resize((self.long, self.width))
        new_img.save('./new_img.png')
        self.img = pygame.image.load('./new_img.png')
        os.remove('./new_img.png')
        c_img = Image.open(self.choose_img)
        new_img = c_img.resize((self.long, self.width))
        new_img.save('./new_img.png')
        self.choose_img = pygame.image.load('./new_img.png')
        os.remove('./new_img.png')

    def bind(self, func):
        """
            绑定函数
            :param func:函数体
            :return: None
            """
        self.func = func

    def blit_button(self, mouse_pos, screen):
        """
            在屏幕上画出按钮
            :param mouse_pos: 鼠标坐标
            :param screen: 屏幕对象
            :return: None
            """
        if self.pos[0] < mouse_pos[0] < self.pos[2] and self.pos[1] < mouse_pos[1] < self.pos[3]:
            self.show_img = self.choose_img
        else:
            self.show_img = self.img
        screen.blit(self.show_img, (self.pos[0], self.pos[1]))
        screen.blit(self.text, (self.rect[0], self.rect[1]))

    def button_click(self, mouse_pos):
        """
            当按下时，传入鼠标坐标，判断是否被按下，调用函数体
            :param mouse_pos: 鼠标坐标元组
            :return: None
            """
        if self.pos[0] < mouse_pos[0] < self.pos[2]:
            if self.pos[1] < mouse_pos[1] < self.pos[3]:
                self.func(self.args)

    def _align_center(self, long, width):
        all_center = (self.pos[0] + long / 2, self.pos[1] + width / 2)
        text_center = [int(all_center[0] - (self.text_size * self.font_size) / 2),
                       int(all_center[1] - self.font_size / 2)]
        return text_center


class ButtonGroup:
    def __init__(self, button_list):
        self.buttons = button_list
        self.functions = []

    def bind_funcs(self, function_list):
        self.functions = function_list
        for i, ii in zip(self.buttons, self.functions):
            i.bind(func=ii)

    def blit_buttons(self, mouse_pos, screen):
        for i in self.buttons:
            i.blit_button(mouse_pos, screen)

    def buttons_click(self, mouse_pos):
        for i in self.buttons:
            i.button_click(mouse_pos)


#  rect, text, text_color, choose_img_path, img_path, font, font_size, args=list
class MonotonyInterfaceButtonList:
    def __init__(self, init_pos, size, texts, text_color, choose_img_path, img_path, font, font_size):
        self.if_alive = False
        self.img = img_path
        self.choose_img = choose_img_path
        self.init_pos = init_pos
        self.size = size
        self.texts = texts
        self.text_color = text_color
        self.font = font
        self.font_size = font_size
        self.interface_buttons = []
        self.funcs = []
        self._init_interface_buttons()
        self.args = {}
        for ii in [index for index, i in enumerate(self.interface_buttons)]:
            self.args[ii] = None

    def _init_interface_buttons(self):
        poses = []
        for i in range(0, len(self.texts)):
            poses.append([self.init_pos[0], self.init_pos[1] + i * self.size[1] + 1])

        for i, ii in zip(self.texts, poses):
            self.interface_buttons.append(
                Interface_Button([ii[0], ii[1], self.size[0], self.size[1]], i, self.text_color, self.choose_img,
                                 self.img, self.font, self.font_size))

    def bind_interface_buttons_funcs(self, funcs):
        self.funcs = funcs
        if len(funcs) != len(self.texts):
            raise errors.VividError(code=10002, status='VividFuncBindError')
        for i, ii in zip(self.interface_buttons, funcs):
            i.bind(func=ii)

    def blit_buttons(self, mouse_pos, screen):
        if self.if_alive:
            for i in self.interface_buttons:
                i.blit_button(mouse_pos, screen)

    def reset_pos(self, new_pos):
        self.init_pos = new_pos
        self.interface_buttons = []
        self._init_interface_buttons()
        for i, ii in zip(self.interface_buttons, self.funcs):
            i.bind(func=ii)
        for i, ii in zip(self.interface_buttons, range(0,len(self.args))):
            i.args = self.args[ii]


    def buttons_click(self, mouse_pos):
        if self.if_alive:
            for i in self.interface_buttons:
                i.button_click(mouse_pos)
            self.if_alive = False

    def bind_args_to_specified_button(self, args, target_index):
        self.args[target_index] = args


if __name__ == '__main__':
    mibl1 = MonotonyInterfaceButtonList((100, 100), [150, 20], ['button1', 'button2', 'button3', 'button4', 'button5'],
                                        (0, 0, 0), 'C:\\Users\\pc\\Desktop\\type\\cmil.png',
                                        'C:\\Users\\pc\\Desktop''\\type\\mil.png', tools.FONT, 20)
    screen = pygame.display.set_mode((500, 500))


    def f1(args=list):
        print('f1')


    def f2(args=list):
        print('f2')


    def f3(args=list):
        print('f3')


    def f4(args=list):
        print('f4')


    def f5(args=list):
        print('f5')


    mibl1.bind_interface_buttons_funcs([f1, f2, f3, f4, f5])
    while True:
        mouse_pos = pygame.mouse.get_pos()

        screen.fill((0, 0, 0))
        mibl1.blit_buttons(mouse_pos, screen)
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s:
                    mibl1.if_alive = True
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mibl1.buttons_click(mouse_pos)
            elif event.type == pygame.QUIT:
                pygame.quit()
        pygame.display.update()
