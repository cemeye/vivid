import time

import pygame
import tools


def get_keys(pressed_keys):
    word = ''
    for i in tools.KEYS:
        if pressed_keys[i]:
            word += tools.KEYS_DICT[i]
            break
    return word


class SearchBox:
    def __init__(self, length, font_size, bg_img_path, choose_img, pos, font,
                 FPS=60):
        self.length = length
        self.size = [length * 10, font_size]
        self.font_size = font_size
        self.pos = pos
        self.bg_img = tools.resize_img(bg_img_path, self.size)
        self.choose_img = tools.resize_img(choose_img, self.size)
        self.now_img = self.bg_img
        self.final_word = ''
        self.font = font
        self.cursor_timer = tools.UpgradesTimer(FPS, 0.4, self.draw_cursor, 'infinity')
        self.cursor_pos = 0
        self.choose_flag = False
        self.flag = True

    def draw_cursor(self, args):
        if self.cursor_timer.flag:
            self.cursor_timer.flag = False
        else:
            self.cursor_timer.flag = True

    def text_render(self):
        if len(self.final_word):
            if len(self.final_word) < 2:
                return self.font.render(self.final_word, False, (0, 0, 0))
            elif self.length >= len(self.final_word) >= 2 and self.final_word[:2] != '//':
                text_render = self.font.render(self.final_word, False, (0, 0, 0))
                return text_render
            elif self.length >= len(self.final_word) >= 2 and self.final_word[:2] == '//':
                text_render = self.font.render(self.final_word, False, (255, 0, 0))
                return text_render
            elif len(self.final_word) > self.length:
                if self.final_word[:2] == '//':
                    return self.font.render(self.final_word[-1 - self.length:-1], False, (255, 0, 0))
                self.cursor_pos = self.length
                return self.font.render(self.final_word[-1 - self.length:-1], False, (0, 0, 0))
        else:
            self.cursor_pos = 0
            return False

    def dispose_words(self, word):
        if word not in ['backspace', 'space', 'return', 'tab', 'left', 'right'] and len(word) == 1:
            if len(self.final_word) < self.length:
                self.cursor_pos += 1
            self.final_word = tools.str_insert(self.final_word, self.cursor_pos, word)
        elif word == 'backspace' and len(self.final_word) > 0:
            if len(self.final_word):
                self.cursor_pos -= 1
            self.final_word = self.final_word[:self.cursor_pos] + self.final_word[self.cursor_pos + 1:]
        elif word == 'space':
            self.cursor_pos += 1
            self.final_word = tools.str_insert(self.final_word, self.cursor_pos, ' ')
        elif word == 'return':
            self.flag = False
        elif word == 'tab':
            self.cursor_pos += 4
            self.final_word = tools.str_insert(self.final_word, self.cursor_pos, '    ')
        elif word == 'left' and self.cursor_pos > 0:
            self.cursor_pos -= 1
        elif word == 'right' and self.cursor_pos < self.length:
            self.cursor_pos += 1

    def search_box_mainloop(self, screen):
        clock = pygame.time.Clock()
        while self.flag:
            clock.tick(60)
            screen.blit(self.now_img, self.pos)
            if self.choose_flag:
                if self.cursor_timer.flag:
                    pygame.draw.rect(screen, (255, 0, 0),
                                     [self.pos[0] + self.cursor_pos * 10 + 2, self.pos[1] + 1, 2,
                                      self.font_size - 2])
                self.cursor_timer.update_new(None)
            if self.text_render():
                screen.blit(self.text_render(), self.pos)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                if event.type == pygame.KEYDOWN and self.choose_flag:
                    print(get_keys(pygame.key.get_pressed()))
                    self.dispose_words(get_keys(pygame.key.get_pressed()))
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if tools.check_point_in_rect(self.pos, [self.pos[0] + self.size[0], self.pos[1] + self.size[1]],
                                                 mouse_pos):
                        self.choose_flag = True
                        self.now_img = self.choose_img
                    else:
                        self.choose_flag = False
                        self.now_img = self.bg_img
            pygame.display.update()


if __name__ == '__main__':
    screen = pygame.display.set_mode((500, 500))
    path = 'C:\\Users\\Administrator\\Desktop\\type\\'
    sb = SearchBox(30, 20, path + 'search_box.png', path + 'choose_search_box.png', [100, 100], tools.FONT)
    sb.search_box_mainloop(screen)
    print(sb.final_word)
