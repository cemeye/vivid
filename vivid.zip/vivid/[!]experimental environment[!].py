from element.Person_walk import *
from widgets.Button import *
from element.DialogBox import *
from scene.Scene import *

pygame.init()
#img_dict = load_imgs('material/sucai/self/')
false = False
# Button.py测试  结果:successfully
if false:
    def print_hello(arg=list):
        print('hello!')


    pygame.font.init()
    font = pygame.font.Font('./pixfont.ttf', 20)
    b1 = Button.Button((100, 100), '你好', (255, 0, 0), 'system/system material/choose_button.png',
                       'system/system material/1234.jpg', font)
    screen = pygame.display.set_mode((500, 500))
    b1.bind(print_hello)
    while True:
        b1.blit_button(pygame.mouse.get_pos(), screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                b1.button_click(mouse_pos)

        pygame.display.update()

# DialogBox.py测试 结果:successfully
if false:
    dialog1 = DialogBox([('me', '哈哈，终于结束了'), ('me', '吃饭吃饭！'), ('me', '嗯....今天晚上吃什么呢？'), ('me', '到了再说吧！')], screen)

    dialog2 = PangBaiDialogBox(['到了食堂', '你正准备点餐，发现饭卡不在身上', '你四处摸索', '你发现你的饭卡落在了宿舍', '你感到一阵恼怒'], screen)

    dialog3 = ChooseDialogBox(['你选择', ('回去拿', '不管了', '大喊一声"绯红之王"！', '这学校，我不待也罢！')], screen,
                              [['你跑回去拿回了饭卡'], ['你轻蔑一笑', '丝毫没有理会，径直离去'], ['绯红之王！', '嗡~', '你惊奇地发现饭卡回到了你身上', '你大吃一惊'],
                               ['你的嘴角上扬，成为了歪嘴龙王']])
    dialog_group = DialogGroup([dialog1, dialog2, dialog3])

    dialog_group.dialogs_run()

# Person_walk.py测试  结果：successfully
if false:
    std = Person('material/sucai/student/girl_friend.png', [0, 0], 3, (40, 50))
    walk_trues = {'up': True, 'down': True, 'left': True, 'right': True}
    while True:
        clock.tick(60)
        std.check(walk_trues)
        screen.fill((0, 0, 0))
        screen.blit(std.img, std.pos)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_a, pygame.K_d, pygame.K_s, pygame.K_w]:
                    if event.key == pygame.K_a:
                        std.start_walk('left')
                    elif event.key == pygame.K_d:
                        std.start_walk('right')
                    elif event.key == pygame.K_w:
                        std.start_walk('up')
                    elif event.key == pygame.K_s:
                        std.start_walk('down')
            elif event.type == pygame.KEYUP:
                if event.key in [pygame.K_a, pygame.K_d, pygame.K_s, pygame.K_w]:
                    std.stop_walk()

        pygame.display.update()

if false:
    walk_trues = {'up': True, 'down': True, 'left': True, 'right': True}
    r1 = Real_Obj((100, 200), (200, 400), (32, 48), 'system/system material/rect.png')
    std = Person('material/sucai/student/girl_friend.png', [0, 0], 3, (32, 48))

    screen = pygame.display.set_mode((500, 500))
    while True:
        clock.tick(60)
        std.check(walk_trues)
        screen.fill((0, 0, 0))
        r1.draw_self(screen)
        std.draw_person(screen)
        walk_trues = r1.collision_detection(std.center, walk_trues)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_a, pygame.K_d, pygame.K_s, pygame.K_w, pygame.K_n]:
                    if event.key == pygame.K_a:
                        std.start_walk('left')
                    elif event.key == pygame.K_d:
                        std.start_walk('right')
                    elif event.key == pygame.K_w:
                        std.start_walk('up')
                    elif event.key == pygame.K_s:
                        std.start_walk('down')
                    elif event.key == pygame.K_n:
                        ...
            elif event.type == pygame.KEYUP:
                if event.key in [pygame.K_a, pygame.K_d, pygame.K_s, pygame.K_w]:
                    std.stop_walk()
        pygame.display.update()



