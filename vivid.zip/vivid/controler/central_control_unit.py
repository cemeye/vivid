from initiator import errors
import json
import os


class Central_Control_Unit:
    """
    中央控制单元，用于统筹协调场景
    """

    def __init__(self, scene_path):
        self.real_objs = []  # 实体
        self.backpack = None  # 背包
        self.player = None  # 角色
        self.attribute = None  # 属性字典
        self.widget = None  # 控件
        self.life_entity = None  # 生命实体
        self.enemy = None  # 敌人
        self.scene = {}  # 场景字典
        self.now_scene = self.scene['start']  # 当前场景

    def bind_real_objs(self, entity_list):
        """
        绑定实体列表
        :param entity_list:实体列表
        :return:None
        """
        for i in entity_list:
            self.real_objs.append(i)

    def remove_real_bojs(self, entity):
        """
        删除实体
        :param entity:实体对象
        :return: None
        """
        try:
            # 删除实体
            self.real_objs.remove(entity)
        except ValueError:
            # 若实体不存在（引发ValueError），则抛出自定义的VividError
            raise errors.VividError(code=10001, status='删除实体时出错，不存在该实体')

    def bind_backpack(self, backpack_obj):
        """
        绑定背包对象
        :param backpack_obj:背包对象
        :return: None
        """
        self.backpack = backpack_obj

    def bind_player(self, player):
        """
        绑定角色对象
        :param player:
        :return: None
        """
        self.player = player

    def bind_attribute(self, attributes):
        """
        绑定属性
        :param attributes:属性dict
        :return:None
        """
        self.attribute = attributes

    def bind_widget(self, widgets):
        """
        绑定控件，包括按钮，进度条等组件
        :param widgets: 组件列表
        :return: None
        """
        if not self.widget:
            self.widget = []
            for i in widgets:
                self.widget.append(i)
        else:
            self.widget = widgets

    def bind_life_entity(self, life_entity):
        """
        绑定生命实体，例如NPC
        :param life_entity:
        :return: None
        """
        if not self.life_entity:
            self.life_entity = []
            for i in life_entity:
                self.life_entity.append(i)
        else:
            self.life_entity = life_entity

    def bind_enemy(self, enemy):
        """
        绑定敌人
        :param enemy: 敌人对象列表
        :return: None
        """
        if not self.enemy:
            self.enemy = []
            for i in enemy:
                self.enemy.append(i)
        else:
            self.enemy = enemy

    def game_mainloop(self):
        """
        游戏主循环
        :return: None
        """
        ...


class Scene_adapter:
    """
    场景适配器，获取场景json文件，读取、处理、计算场景与场景之间的对应关系、
    在触发【场景切换】事件后查找，统筹处理场景
    """

    def __init__(self, dialog_path, real_obj_path):
        self.scene_dict = []

    def find_ID(self, ID):
        """
        此方法用于获取ID对应的场景
        :param ID: ID
        :return: Scene
        """
        return self.scene_dict[ID]

    def analysis_scene_json(self, json_str):
        """
        此方法用于解析获取到的json数据，并转化为场景对象
        :return: Scene
        """
        ...

    def reset_scene(self, ccu, player, ID, life_entity=None, enemy=None):
        ccu.real_objs = []
        ccu.player = player
        ccu.life_entity = life_entity
        ccu.enemy = enemy
        ccu.now_scene = self.find_ID(ID)
