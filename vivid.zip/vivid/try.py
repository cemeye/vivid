print('mcmcmcm'[:-1])
mycolcor = (0, 0, 255)
x = 300
y = 250
position = (x, y, 100, 100)
width = 0
pygame.draw.rect(screen, mycolcor, position, width)