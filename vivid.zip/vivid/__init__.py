# back_ground_loader.py    导入实体文件
#
# Button.py  内有按钮类
#     --Button    普通按钮
#     --Interface_Button     更高级，更麻烦的按钮
#
# DialogBox.py    内有对话框类
#     --DialogBox     普通对话框
#     --PangBaiDialogBox      旁白对话框（较为简单）
#     --ChooseDialogBox    选择对话框
#     --DialogGroup   对话框组
#
# Person_Walk.py    内有角色与移动类
#     --Person    角色移动(格式化移动方法暂未实现)
#     --ActionGroup    动作组对象(暂未实现)
#     --Action    动作对象（绑定于动作组或角色，暂未实现）
#
# RealObj.py    内有实体类
#     --return_S  返回两点间欧式距离
#     --check_point_in_rect   检查给定点是否在矩形范围内，返回布尔值
#     --clac_linear_function  给定两点，返回次两点确定的一元一次函数的k与b值
#     --RealObj   实体对象
#         ---RealObj_With_Dialog    继承于RealObj对象，用于实例化带有对话框的实体
#
# RPGmaker.py    用于亲自绘画制作实体
#     --resize_img    缩放图片函数
#     --Scene_Core    总控台对象
#     --Rect_Draw_Screen    矩形绘制画布
#
# Scene.py     内有移动场景对象
#     --Immovable_Scene   不可移动，固定场景
#
# Start_Scene.py    内有启动画面类对象
#     --Start_Scene   启动画面类1
#
# tools.py    内涵多种工具类方法
#     --load_imgs     返回图片surface字典
#     --Timer     计时器类，不会滞留主进程，可循环调用
#     --check_in_rect     检测点是否在矩形内部，与前面有重叠
#     --show_error        在屏幕上显示出错误框
#     --crop_img    剪裁图片
#
# TUD.py    用于显示上升式字幕
#     --TUD    字幕类对象
#
# Work_Persent.py
#     --Work_Persent    实例化进度条对象
#     --Gradient_progress_bar    可渐变式进度条（会稍稍阻塞主进程，约0.1~1秒左右，视一次性扣除值而定）
#
# animations.py
#     --
#     --
#     --
#     --