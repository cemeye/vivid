import json
import random


def str2list(s):
    list_new = [0, 0]
    print(s[1:-1].split(','))
    list_new[0] = int(s[1:-1].split(',')[0])
    list_new[1] = int(s[1:-1].split(',')[1])
    return list_new


def create_scene_ID(scene_name):
    id_path = input('请输入场景ID管理文件(SID)路径:')
    ids = []
    with open(id_path, 'r') as f:
        ids_with_names = f.read().split('\n')
        for i in ids_with_names:
            ids.append(i.split('->')[0])

    id_ = random.randint(10000, 99999)
    while id_ in ids:
        id_ = random.randint(10000, 99999)
    with open(id_path, 'a') as f:
        f.write(str(id_) + '->' + scene_name + '\n')
    return id_


def create_scene_json():
    global scene_json
    scene_json['scene_name'] = scene_name_
    scene_json['player_init_pos'] = player_init_pos
    scene_json['background_path'] = background
    scene_json['ID'] = create_scene_ID(scene_name_)
    scene_json['real_obj_path'] = real_obj
    scene_json['player_img'] = player_img
    scene_json['dialog_path'] = scene_dialogs_
    scene_json['type'] = scene_type
    with open(save_path, 'w') as f:
        f.write(json.dumps(scene_json))
    return


real_obj = input('请输入实体文件路径:')
# bg_path, player_init_pos_list, player_path
background = input('请输入背景图片路径:')

player_init_pos = str2list(input('请输入玩家初始位置:'))

player_img = input('请输入玩家4x4动画图片路径，每帧大小32x48:')

scene_dialogs_ = input('请输入实体绑定的对话文件:')

scene_type = int(input('请输入场景类型（场景可移动或不可移动，可移动为1，不可移动为2）：'))

scene_name_ = input('请输入场景名称(用于显示切换场景时的提示):')

save_path = input('请输入场景文件保存路径:')

scene_json = {}

create_scene_json()
