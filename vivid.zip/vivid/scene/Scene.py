import pygame
import sys
import copy
from element import Person_walk, RealObj


def kelong(a):
    return copy.deepcopy(a)


class Immovable_Scene:
    """
    不可移动场景
    方法：1刷新实体  2绑定实体 3场景主循环

    """

    def __init__(self, bg_path, player_init_pos_list, player_path, screen=None,  player_size=(32, 48), player_speed=3):
        self.clock = pygame.time.Clock()
        self.pos = None
        self.real_objs = []
        self.walk_trues = {'up': True, 'down': True, 'left': True, 'right': True}
        self.background_img = pygame.image.load(bg_path)
        self.player_pos = player_init_pos_list
        self.player = Person_walk.Person(player_path, self.player_pos, player_speed, player_size)
        self.flag = True
        self.selected_entity = []
        if not screen:
            self.screen = pygame.display.set_mode((500, 500))
        else:
            self.screen = screen
            self.pos = (500, 300)

    def update_real_objs(self):
        chosen_objs = []
        for i in self.real_objs:
            i.draw_self(self.screen)  # 画出实体
            flag = i.collision_detection(self.player.center, self.walk_trues)
            if flag:
                self.walk_trues = flag  # 碰撞
                if not flag['up'] or not flag['down'] or not flag['left'] or not flag['right']:
                    chosen_objs.append(i)
        if not len(chosen_objs):
            self.walk_trues = {'up': True, 'down': True, 'left': True, 'right': True}
        self.selected_entity = chosen_objs

    def bind_real_objs(self, real_objs):
        self.real_objs = real_objs

    def _blit_bg(self):
        if self.pos:
            self.screen.blit(self.background_img, self.pos)
        else:
            self.screen.blit(self.background_img, (0, 0))

    def scene_main_loop(self):
        while self.flag:
            self.clock.tick(60)
            self.screen.fill((0, 0, 0))
            self._blit_bg()  # 绘画背景图片
            self.screen.blit(self.player.img, self.player.pos)  # 画出角色的坐标和图像
            self.update_real_objs()
            self.player.check(self.walk_trues)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key in [pygame.K_a, pygame.K_d, pygame.K_s, pygame.K_w, pygame.K_n]:
                        if event.key == pygame.K_a:
                            self.player.start_walk('left')
                        elif event.key == pygame.K_d:
                            self.player.start_walk('right')
                        elif event.key == pygame.K_w:
                            self.player.start_walk('up')
                        elif event.key == pygame.K_s:
                            self.player.start_walk('down')
                        elif event.key == pygame.K_n and self.selected_entity:
                            for i in self.selected_entity:
                                if i.dialogs:
                                    i.show_dialog()
                                    break
                elif event.type == pygame.KEYUP:
                    if event.key in [pygame.K_a, pygame.K_d, pygame.K_s, pygame.K_w]:
                        self.player.stop_walk()

            pygame.display.update()


class Movable_Scene:
    def __init__(self, bg_path, player_init_pos_list, player_path, length, width, screen=None):
        self.clock = pygame.time.Clock()  # 创建时钟
        self.pos = None  # 坐标（若为嵌入式窗口时用得到）
        self.real_objs = []  # 实体列表
        self.walk_trues = {'up': True, 'down': True, 'left': True, 'right': True}  # 真真的行走权限
        self.background_img = pygame.image.load(bg_path)  # 背景图片
        self.player_pos = (234, 226)  # 玩家固定位置
        self.player = Person_walk.Person(player_path, self.player_pos, 3, (32, 48))  # 玩家
        self.flag = True  # 场景是否结束的标志符
        self.selected_entity = []  # 被选中的实体

        self.length = length
        self.width = width
        self.bg_pos = self.transform_relative_coordinates(player_init_pos_list)
        self.walk = False
        self.position = 'down'
        if not screen:
            self.screen = pygame.display.set_mode((500, 500))
        else:  # 此段用于判断嵌入式窗口，若无指定窗口则自行创建
            self.screen = screen
            self.pos = (500, 300)

    def transform_relative_coordinates(self, pos):
        """
        此方法用于相对坐标变换
        :param pos: 原坐标
        :return: pos_list
        """
        pos_list = [0, 0]
        pos_list[0] = -1 * (pos[0] - 250)
        pos_list[1] = -1 * (pos[1] - 250)
        return pos_list

    def bind_real_objs(self, real_objs):
        """
        初始化，并绑定实体列表
        """
        for i in real_objs:
            i.pos[0] += self.bg_pos[0]
            i.pos[1] += self.bg_pos[1]
            i.final_pos[0] += self.bg_pos[0]
            i.final_pos[1] += self.bg_pos[1]
            i.recalculate()
        self.real_objs = real_objs

    def detecting_scene_boundary(self):
        """
        检测玩家与地图边界
        :return: None
        """
        if self.bg_pos[0] >= 0 + 250:
            self.player.trues['left'] = False
        else:
            self.player.trues['left'] = True
        if self.bg_pos[0] <= 500 - self.length - 250:
            self.player.trues['right'] = False
        else:
            self.player.trues['right'] = True
        if self.bg_pos[1] >= 0 + 250:
            self.player.trues['up'] = False
        else:
            self.player.trues['up'] = True
        if self.bg_pos[1] <= 500 - self.width - 250:
            self.player.trues['down'] = False
        else:
            self.player.trues['down'] = True

    def update_objs(self):
        change_dict = {'up': (1, 1), 'down': (1, -1), 'left': (0, 1), 'right': (0, -1)}
        if self.walk and self.walk_trues[self.position]:
            self.bg_pos[change_dict[self.position][0]] += self.player.speed * change_dict[self.position][1]  # 背景图片移动
            for i in self.real_objs:
                i.pos[change_dict[self.position][0]] += self.player.speed * change_dict[self.position][1]
                i.final_pos[change_dict[self.position][0]] += self.player.speed * change_dict[self.position][1]
                i.recalculate()

    def check_peng(self):
        chosen_objs = []
        for i in self.real_objs:
            flag = i.collision_detection(self.player.center, self.walk_trues)
            if flag:
                self.walk_trues = flag  # 碰撞
                if not flag['up'] or not flag['down'] or not flag['left'] or not flag['right']:
                    chosen_objs.append(i)

        if not len(chosen_objs):
            self.walk_trues = {'up': True, 'down': True, 'left': True, 'right': True}
        self.selected_entity = chosen_objs

    def scene_mainloop(self):
        while self.flag:
            self.check_peng()
            self.clock.tick(60)
            self.screen.fill((0, 0, 0))
            self.screen.blit(self.background_img, self.bg_pos)
            self.screen.blit(self.player.img, self.player.pos)  # 画出角色的坐标和图像
            for i in self.real_objs:
                i.draw_self(self.screen)  # 画出实体
            self.player.check_in_movable_scene(self.walk_trues)  # 行走检测
            # self.detecting_scene_boundary()
            self.update_objs()
            for event in pygame.event.get():  # 事件处理for循环
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT]:
                        if event.key == pygame.K_UP:
                            self.player.just_show_walk('up')
                            self.position = 'up'
                        elif event.key == pygame.K_DOWN:
                            self.player.just_show_walk('down')
                            self.position = 'down'
                        elif event.key == pygame.K_LEFT:
                            self.player.just_show_walk('left')
                            self.position = 'left'
                        elif event.key == pygame.K_RIGHT:
                            self.player.just_show_walk('right')
                            self.position = 'right'
                        self.walk = True
                    elif event.key == pygame.K_n and len(self.selected_entity):
                        for i in self.selected_entity:
                            if i.dialogs:
                                i.show_dialog()
                                break
                elif event.type == pygame.KEYUP:
                    if event.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT]:
                        self.player.just_stop_walk()
                        self.walk = False
            pygame.display.update()


class Combat_Immovable_Scene:
    def __init__(self, bg_path, player_init_pos_list, player_path, player_size=(32, 48), player_speed=3, screen=None):
        self.clock = pygame.time.Clock()
        self.pos = None
        self.real_objs = []
        self.walk_trues = {'up': True, 'down': True, 'left': True, 'right': True}
        self.background_img = pygame.image.load(bg_path)
        self.player_pos = player_init_pos_list
        self.player = Person_walk.AssaultPlayer(player_path, self.player_pos, player_speed, player_size)
        self.flag = True
        self.selected_entity = []
        if not screen:
            self.screen = pygame.display.set_mode((500, 500))
        else:
            self.screen = screen
            self.pos = (500, 300)

        self.drop = []

    def update_real_objs(self):
        chosen_objs = []
        for i in self.real_objs:
            i.draw_self(self.screen)  # 画出实体
            flag = i.collision_detection(self.player.center, self.walk_trues)
            if flag:
                self.walk_trues = flag  # 碰撞
                if not flag['up'] or not flag['down'] or not flag['left'] or not flag['right']:
                    chosen_objs.append(i)
        if not len(chosen_objs):
            self.walk_trues = {'up': True, 'down': True, 'left': True, 'right': True}
        self.selected_entity = chosen_objs

    def bind_real_objs(self, real_objs):
        self.real_objs = real_objs

    def _blit_bg(self):
        if self.pos:
            self.screen.blit(self.background_img, self.pos)
        else:
            self.screen.blit(self.background_img, (0, 0))

    def update_drops(self):
        for i in self.drop:
            for ii in i:
                self.screen.blit(ii[0].img, ii[1])

    def scene_main_loop_new(self, lel):
        while self.flag:
            self.clock.tick(60)
            self.screen.fill((0, 0, 0))
            self._blit_bg()  # 绘画背景图片
            self.update_drops()  # 画出掉落物
            self.player.draw_person(self.screen)
            self.update_real_objs()
            self.player.check_new(self.walk_trues, lel, self.screen)
            for i in lel:
                if i.is_alive:
                    i.life_entity_update_new(self, 0.5, self.player)
                else:
                    lel.remove(i)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key in [pygame.K_a, pygame.K_d, pygame.K_s, pygame.K_w, pygame.K_n]:
                        if event.key == pygame.K_a:
                            self.player.start_walk('left')
                        elif event.key == pygame.K_d:
                            self.player.start_walk('right')
                        elif event.key == pygame.K_w:
                            self.player.start_walk('up')
                        elif event.key == pygame.K_s:
                            self.player.start_walk('down')
                        elif event.key == pygame.K_b and self.selected_entity:
                            for i in self.selected_entity:
                                if i.dialogs:
                                    i.show_dialog()
                                    break
                        elif event.key == pygame.K_n:
                            self.player.ammunition.accumulator.start_update()
                elif event.type == pygame.KEYUP:
                    if event.key in [pygame.K_a, pygame.K_d, pygame.K_s, pygame.K_w]:
                        self.player.stop_walk()
                    elif event.key == pygame.K_n:
                        self.player.ammunition.accumulator.stop_charge(
                            [self.player.ammunition.direction, kelong(self.player.danyao_pos)])
            pygame.display.update()

    # ca = CombatAnimation(path + 'ca1.png', [50, 50], 2, 0.2, screen, [50, 50])
    # ba1.bind_accumulator(accu1)
    # ba1.bind_animation(ca)
    # player.bind_ammunition(ba1)


if __name__ == '__main__':
    from initiator import realobj_loader

    sa = realobj_loader.DialogSceneMixer(dialog_path='C:\\Users\\pc\\Desktop\\type\\对话文件实例.json',
                                         real_obj_path='C:\\Users\\pc\\Desktop\\type\\实体文件实例.json')

    s2 = Movable_Scene('C:\\Users\\pc\\Desktop\\type\\bg2.png', [0, 0], 'C:\\Users\\pc\\Desktop\\type\\me_walk.png',
                       1400, 800)
    realobjs = sa.mix(screen=s2.screen)
    s2.bind_real_objs(realobjs)
    s2.scene_mainloop()
    # s1 = Immovable_Scene('C:\\Users\\pc\\Desktop\\type\\bg1.png', [500, 500],
    #                     'C:\\Users\\pc\\Desktop\\type\\me_walk.png')
    # realobjs = sa.mix(screen=s1.screen)
    # s1.bind_real_objs(realobjs)
    # s1.scene_main_loop()
