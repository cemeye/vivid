from Button import Interface_Button
import pygame

pygame.init()
font = pygame.font.Font('./system/system material/pixfont.ttf', 20)


class Start_Scene:
    def __init__(self, bg_img_path):
        pygame.init()
        self.flag = True
        self.img = pygame.image.load(bg_img_path)
        self.start_b = Interface_Button((340, 150, 150, 30), '开始游戏', (255, 0, 0),
                                        'system/system material/choose_button.png',
                                        'system/system material/1234.jpg', font, 20)
        self.read_b = Interface_Button((340, 210, 150, 30), '读取游戏', (255, 0, 0),
                                       'system/system material/choose_button.png',
                                       'system/system material/1234.jpg', font, 20)
        self.set_b = Interface_Button((340, 270, 150, 30), '设置', (255, 0, 0),
                                      'system/system material/choose_button.png',
                                      'system/system material/1234.jpg', font, 20)
        self.exit_b = Interface_Button((340, 330, 150, 30), '退出游戏', (255, 0, 0),
                                       'system/system material/choose_button.png',
                                       'system/system material/1234.jpg', font, 20)
        self.buttons = [self.start_b, self.read_b, self.set_b, self.exit_b]
        self.screen = pygame.display.set_mode((500, 500))
        self._bind_funcs()

    def blit_buttons(self, mouse_pos):
        for i in self.buttons:
            i.blit_button(mouse_pos, self.screen)

    def buttons_click(self, mouse_pos):
        for i in self.buttons:
            i.button_click(mouse_pos)

    def start_scene_mainloop(self):
        while self.flag:
            mouse_pos = pygame.mouse.get_pos()
            self.screen.blit(self.img, (0, 0))
            self.blit_buttons(mouse_pos)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.buttons_click(mouse_pos)
            pygame.display.update()

    def _bind_funcs(self):
        self.start_b.bind(self.start)
        self.exit_b.bind(self.exit)
        self.set_b.bind(self.set)
        self.read_b.bind(self.read)

    def start(self, arg=list):
        self.flag = False

    def exit(self, arg=list):
        pygame.quit()

    def set(self, arg=list):
        print('暂未实现')

    def read(self, arg=list):
        print('暂未实现')


Start_Scene('../material/sucai/self/startscene.png').start_scene_mainloop()
