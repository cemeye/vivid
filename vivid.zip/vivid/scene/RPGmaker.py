import pygame.image
import json
from widgets.Button import *
from Scene import *
import tools

"""
这个程序用来绘制实体矩形与具有对话属性的矩形
"""

TYPE = 'REALOBJ'


def resize_img(img_path, rect):  # x,y,long,width
    try:
        img = Image.open(img_path)
        new_img = img.resize((rect[2], rect[3]))
        new_img.save('./new_img_w.png')
        img = pygame.image.load('./new_img_w.png')
        os.remove('./new_img_w.png')
        return img
    except ValueError:
        return False


def blits_scene(rect_draw_screen, scene, pos):
    rect_draw_screen.draw_wall()
    scene.blit_objs()
    scene.blit_buttons(pos)


class Scene_Core:
    """
    定义主控器，用于存储全局变量
    """

    def __init__(self, path):
        self.screen = pygame.display.set_mode((600, 600))
        pygame.font.init()
        self.font = tools.FONT
        self.NPC = []
        self.buttons = []
        self.rect_s = (0, 0)
        self.rect_f = (0, 0)
        self.type = 'draw_rects'
        self.draw_objs = []
        self.obj_list = []
        self.bg_file = open(path, 'w')

    def blit_objs(self):
        """
        画出需要显示的图片
        """
        for i in self.draw_objs:
            self.screen.blit(i[0], i[1])

    def bind_button(self, button):
        for i in button:
            self.buttons.append(i)

    def blit_buttons(self, mouse_pos):
        """
        画出按钮组组件，并检测点击事件
        """
        for i in self.buttons:
            i.blit_button(mouse_pos, self.screen)

    def buttons_click(self, mouse_pos):
        for i in self.buttons:
            i.button_click(mouse_pos)

    def mainloop(self, scene, rect_draw_screen):
        scene.screen_.fill((255, 255, 200))
        while True:
            pos = pygame.mouse.get_pos()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    scene.buttons_click(pos)
                    rect_draw_screen.check_draw_rect(pos, 'start', scene)
                elif event.type == pygame.MOUSEBUTTONUP:
                    rect_draw_screen.check_draw_rect(pos, 'final', scene)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_z:
                        try:
                            scene.draw_objs.remove(scene.draw_objs[-1])
                            scene.real_obj.remove(scene.real_obj[-1])
                        except IndexError:
                            tools.show_error(scene.screen_, '[！]vivid引擎引发IndexError', '于函数mainloop()中:', scene.font,
                                             (50, 250))
                            scene.screen_.fill((255, 255, 200))
                blits_scene(rect_draw_screen, scene, pos)
            pygame.display.update()


class Rect_Draw_Screen:
    """
    定义画布,用于绘制矩形
    """

    def __init__(self, pos, screen, img_path, wall_path):
        self.pos = pos
        self.screen = screen
        self.wall_path = pygame.image.load(wall_path)
        self.img = pygame.image.load(img_path)

    def draw_wall(self):
        """
        在屏幕上画出背景墙
        """
        self.screen.blit(self.wall_path, self.pos)

    def check_draw_rect(self, mouse_pos, type, Scene_Core):
        """
        检测是否绘制矩形，如果绘制便在主控单元内加入绘画实体
        """
        if self.pos[0] < mouse_pos[0] < self.pos[0] + 500 and self.pos[1] < mouse_pos[1] < self.pos[1] + 500:
            if type == 'start':
                Scene_Core.rect_s = mouse_pos
            elif type == 'final' and 0 < Scene_Core.rect_s[0] < 500 and 0 < Scene_Core.rect_s[1] < 500:
                Scene_Core.rect_f = mouse_pos
                rect_long = Scene_Core.rect_f[0] - Scene_Core.rect_s[0]
                rect_width = Scene_Core.rect_f[1] - Scene_Core.rect_s[1]
                resize_img_new = resize_img('../material/system/system material/real_obj.png',
                                            (Scene_Core.rect_s[0], Scene_Core.rect_s[1], rect_long, rect_width))
                resize_img_dialog_new = resize_img('../material/system/system material/real_obj_with_dialog.png',
                                                   (Scene_Core.rect_s[0], Scene_Core.rect_s[1], rect_long, rect_width))
                if resize_img_new:
                    if TYPE == 'REALOBJ':
                        img_rect = resize_img_new
                        Scene_Core.obj_list.append(
                            {"type": "Real_Obj", "pos": Scene_Core.rect_s, "final_pos": Scene_Core.rect_f,
                             "player_size": [32, 48], "img_path": "C:\\Users\\pc\\Desktop\\type\\r1.png"})
                    else:
                        img_rect = resize_img_dialog_new
                        Scene_Core.obj_list.append(
                            {"type": "Real_Obj_With_Dialog", "pos": Scene_Core.rect_s, "final_pos": Scene_Core.rect_f,
                             "player_size": [32, 48], "img_path": "C:\\Users\\pc\\Desktop\\type\\r1.png"})
                    Scene_Core.draw_objs.append([img_rect, (Scene_Core.rect_s, Scene_Core.rect_f)])


# -------------------------------------------------------------------------------------------------------------------------------


scene_ = Scene_Core('../material/01.ros')
rectdrawscreen = Rect_Draw_Screen((0, 0), scene_.screen, '../material/system/system material/real_obj.png',
                                  '../material/system/system material/draw_screen.png')
# (self, pos, text, text_color, choose_img_path, img_path, font, args=list)
b1 = Button((0, 500), '保存至地图', (0, 0, 255), '../material/system/system material/choose_button.png',
            '../material/system/system material/1234.jpg', scene_.font)
b2 = Button((0, 550), '切换模式', (0, 0, 255), '../material/system/system material/choose_button.png',
            '../material/system/system material/1234.jpg', scene_.font)
b3 = Button((150, 500), '导入地图', (0, 0, 255), '../material/system/system material/choose_button.png',
            '../material/system/system material/1234.jpg', scene_.font, args=rectdrawscreen)


def bind_func1(args=list):
    scene_.bg_file.write(json.dumps(scene_.obj_list))
    scene_.bg_file.close()
    sys.exit()


def bind_func2(args=list):
    global TYPE
    if TYPE == 'REALOBJ':
        TYPE = 'REALOBJWITHDIALOG'
    else:
        TYPE = 'REALOBJ'


def bind_func3(args):
    path = input('请输入地图路径:')
    try:
        args.wall_path = pygame.image.load(path)
    except FileNotFoundError:
        tools.show_error(scene_.screen, '导入文件失败！', __file__, scene_.font, (10, 170))


b1.bind(bind_func1)
b2.bind(bind_func2)
b3.bind(bind_func3)
scene_.bind_button([b1, b2, b3])
# -------------------------------------------------------------------------------------------------------------------------------


scene_.mainloop(scene_, rectdrawscreen)
